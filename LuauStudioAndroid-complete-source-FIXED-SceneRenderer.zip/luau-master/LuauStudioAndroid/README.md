# Luau Engine Studio Android

Native Android 3D editor built around the official Luau VM/compiler source in this repository.

## Current implementation
- Android ARM64 Gradle/NDK project
- Real OpenGL ES 3.0 3D viewport
- Touch camera orbit/zoom and object selection
- Part creation: Block, Sphere, Cylinder, Wedge, CornerWedge
- Move/Rotate/Scale via numeric dialogs and touch drag
- Explorer hierarchy with Services, folders and objects
- Properties editor for core Part properties
- Script/LocalScript/ModuleScript source editor
- Luau compile+run through the embedded official Luau VM
- Output panel with INFO/WARNING/ERROR/PRINT
- RBXLX import/export with a loss-aware generic XML tree and unknown-instance preservation
- Android Storage Access Framework import/export
- Local project save/load
- LOW-END/BALANCED/HIGH quality profiles
- Progressive parsing on a worker thread

## Toolchain
- Android Gradle Plugin 8.13.x
- Gradle 8.13
- compileSdk 36
- minSdk 26
- NDK 27.3 LTS (r27d) is recommended and can be changed in `app/build.gradle`
- ABI: arm64-v8a

This project intentionally does not contain or depend on Roblox proprietary Studio code/assets.

## Build automation

A GitHub Actions workflow is included at `../.github/workflows/build-android.yml`. It provisions Android SDK/NDK and Gradle on a GitHub runner and uploads the resulting ARM64 debug APK.
