package org.luauengine.studio;

public final class NativeBridge {
    static { System.loadLibrary("luau_studio"); }
    public static native void nativeInit();
    public static native void nativeNewProject();
    public static native String nativeSceneJson();
    public static native String nativeHierarchyJson();
    public static native int nativeObjectCount();
    public static native String nativeCreatePart(String shape);
    public static native String nativeCreateObject(String cls,String parentId);
    public static native String nativeDuplicate(String id);
    public static native boolean nativeDelete(String id);
    public static native boolean nativeMove(String id,String parentId);
    public static native boolean nativeSetProperty(String id,String key,String value);
    public static native String nativeGetProperties(String id);
    public static native String nativeGetSource(String id);
    public static native String nativeSetSource(String id,String source);
    public static native String nativeRun();
    public static native void nativeStop();
    public static native String nativeImportRbxlx(String xml);
    public static native String nativeExportRbxlx();
    private NativeBridge() {}
}
