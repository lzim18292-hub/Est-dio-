package org.luauengine.studio;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.view.inputmethod.EditorInfo;
import android.widget.*;
import android.text.*;
import android.text.style.ForegroundColorSpan;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends Activity {
    private FrameLayout root;
    private ViewportView viewport;
    private LinearLayout sidePanel;
    private TextView status;
    private TextView panelTitle;
    private LinearLayout panelBody;
    private ProgressBar progress;
    private final ExecutorService io=Executors.newFixedThreadPool(2);
    private String selectedId="", selectedScriptId="";
    private final java.util.HashSet<String> collapsed=new java.util.HashSet<>();
    private EditText scriptEditor;
    private EditText explorerSearch;
    private String lastOutput = "[]";
    private volatile boolean runtimeRunning = false;
    private TextView lineNumbers;
    private String quality="BALANCED";
    private static final int OPEN=1001, EXPORT=1002;

    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);NativeBridge.nativeInit();buildUi();refreshAll();}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private Button btn(String t){Button b=new Button(this);b.setText(t);b.setTextSize(11);b.setSingleLine(true);b.setPadding(dp(5),0,dp(5),0);return b;}
    private TextView label(String t){TextView v=new TextView(this);v.setText(t);v.setTextColor(Color.LTGRAY);v.setTextSize(12);v.setPadding(dp(8),dp(5),dp(8),dp(5));return v;}
    private void buildUi(){
        root=new FrameLayout(this);root.setBackgroundColor(Color.rgb(13,17,23));
        viewport=new ViewportView(this);viewport.getEditorRenderer().setQuality(quality);root.addView(viewport,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout top=new LinearLayout(this);top.setOrientation(LinearLayout.HORIZONTAL);top.setGravity(Gravity.CENTER_VERTICAL);top.setPadding(dp(4),dp(2),dp(4),dp(2));top.setBackgroundColor(Color.rgb(20,25,33));
        addTop(top,"NEW",v->newProject());addTop(top,"OPEN",v->openImport());addTop(top,"SAVE",v->saveLocal());addTop(top,"EXPORT",v->exportProject());addTop(top,"PLAY",v->runProject());addTop(top,"STOP",v->{NativeBridge.nativeStop();showStatus("Stop requested; current script will finish");});addTop(top,"PART",v->createPart());addTop(top,"MODEL",v->createObj("Model"));addTop(top,"SCRIPT",v->createObj("Script"));addTop(top,"TOOLBOX",v->showPanel("TOOLBOX"));addTop(top,"EXPLORER",v->showPanel("EXPLORER"));addTop(top,"PROP",v->showPanel("PROPERTIES"));addTop(top,"OUTPUT",v->showPanel("OUTPUT"));addTop(top,"QUAL",v->cycleQuality());
        FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(-1,dp(48),Gravity.TOP);root.addView(top,tp);
        LinearLayout tools=new LinearLayout(this);tools.setOrientation(LinearLayout.HORIZONTAL);tools.setGravity(Gravity.CENTER);tools.setPadding(dp(4),dp(2),dp(4),dp(2));tools.setBackgroundColor(Color.argb(230,27,32,41));
        for(String t:new String[]{"SELECT","MOVE","ROTATE","SCALE"}){Button b=btn(t);b.setOnClickListener(v->viewport.getEditorRenderer().setTool(((Button)v).getText().toString()));tools.addView(b,new LinearLayout.LayoutParams(0,dp(36),1));}
        FrameLayout.LayoutParams tlp=new FrameLayout.LayoutParams(-1,dp(40),Gravity.BOTTOM);tlp.bottomMargin=dp(3);root.addView(tools,tlp);
        sidePanel=new LinearLayout(this);sidePanel.setOrientation(LinearLayout.VERTICAL);sidePanel.setBackgroundColor(Color.rgb(17,21,28));
        panelTitle=label("EXPLORER");panelTitle.setTextSize(14);panelTitle.setTypeface(Typeface.DEFAULT,Typeface.BOLD);panelTitle.setBackgroundColor(Color.rgb(25,30,39));sidePanel.addView(panelTitle,new LinearLayout.LayoutParams(-1,dp(42)));
        ScrollView scroll=new ScrollView(this);panelBody=new LinearLayout(this);panelBody.setOrientation(LinearLayout.VERTICAL);scroll.addView(panelBody);sidePanel.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        FrameLayout.LayoutParams spp=new FrameLayout.LayoutParams(dp(320),-1,Gravity.RIGHT);spp.topMargin=dp(48);spp.bottomMargin=dp(43);root.addView(sidePanel,spp);sidePanel.setVisibility(View.GONE);
        status=label("Ready • 0 objects");status.setBackgroundColor(Color.argb(210,10,12,16));FrameLayout.LayoutParams st=new FrameLayout.LayoutParams(-1,dp(28),Gravity.BOTTOM);st.bottomMargin=dp(43);root.addView(status,st);
        progress=new ProgressBar(this);progress.setVisibility(View.GONE);FrameLayout.LayoutParams pp=new FrameLayout.LayoutParams(dp(40),dp(40),Gravity.CENTER);root.addView(progress,pp);
        viewport.getEditorRenderer().setSelectionListener(id->{selectedId=id;runOnUiThread(()->showPanel("PROPERTIES"));});
        setContentView(root);
    }
    private void addTop(LinearLayout p,String t,View.OnClickListener l){Button b=btn(t);b.setOnClickListener(l);p.addView(b,new LinearLayout.LayoutParams(0,-1,1));}
    private void showStatus(String s){status.setText(s+" • "+NativeBridge.nativeObjectCount()+" objects");}
    private void refreshAll(){viewport.getEditorRenderer().refresh();buildExplorer();showStatus("Project ready");}
    private void newProject(){NativeBridge.nativeNewProject();selectedId="";refreshAll();}
    private void cycleQuality(){quality=quality.equals("LOW-END")?"BALANCED":quality.equals("BALANCED")?"HIGH":"LOW-END";viewport.getEditorRenderer().setQuality(quality);showStatus("Quality: "+quality);}
    private void createPart(){String[] shapes={"Block","Sphere","Cylinder","Wedge","CornerWedge"};new AlertDialog.Builder(this).setTitle("Create Part").setItems(shapes,(d,w)->{selectedId=NativeBridge.nativeCreatePart(shapes[w]);refreshAll();showPanel("PROPERTIES");}).show();}
    private void createObj(String cls){String id=NativeBridge.nativeCreateObject(cls,selectedId);refreshAll();if(cls.contains("Script")){selectedScriptId=id;showPanel("SCRIPT EDITOR");}else showPanel("PROPERTIES");}
    private void buildToolbox(){panelTitle.setText("TOOLBOX");panelBody.addView(label("Built-in local assets — no server required."));panelBody.addView(label("PRIMITIVES"));for(String shape:new String[]{"Block","Sphere","Cylinder","Wedge","CornerWedge"}){Button b=btn("PART • "+shape);b.setOnClickListener(v->{selectedId=NativeBridge.nativeCreatePart(shape);refreshAll();showPanel("PROPERTIES");});panelBody.addView(b,new LinearLayout.LayoutParams(-1,dp(42)));}panelBody.addView(label("OBJECTS"));for(String cls:new String[]{"Model","Folder","Script","LocalScript","ModuleScript","ScreenGui","Frame","TextLabel","TextButton","ImageLabel","ImageButton"}){Button b=btn(cls);b.setOnClickListener(v->createObj(cls));panelBody.addView(b,new LinearLayout.LayoutParams(-1,dp(42)));}panelBody.addView(label("Imported MeshPart / Decal / Sound instances are preserved in RBXLX metadata; dedicated local asset decoding remains a future renderer module."));}
    private void showAddMenu(){String[] items={"Part","Model","Folder","Script","LocalScript","ModuleScript","ScreenGui","Frame","TextLabel","TextButton","ImageLabel","ImageButton"};new AlertDialog.Builder(this).setTitle("Add Object").setItems(items,(d,w)->{String cls=items[w];if(cls.equals("Part"))createPart();else createObj(cls);}).show();}
    private void showPanel(String which){sidePanel.setVisibility(View.VISIBLE);panelTitle.setText(which);panelBody.removeAllViews();switch(which){case"EXPLORER":buildExplorer();break;case"PROPERTIES":buildProperties();break;case"OUTPUT":buildOutput();break;case"SCRIPT EDITOR":buildScriptEditor();break;case"TOOLBOX":buildToolbox();break;default:break;}}
    private void buildExplorer(){if(panelBody==null)return;panelTitle.setText("EXPLORER");panelBody.removeAllViews();
        explorerSearch=new EditText(this);explorerSearch.setSingleLine(true);explorerSearch.setHint("Search Explorer...");explorerSearch.setHintTextColor(Color.GRAY);explorerSearch.setTextColor(Color.WHITE);explorerSearch.setTextSize(12);explorerSearch.setPadding(dp(8),0,dp(8),0);panelBody.addView(explorerSearch,new LinearLayout.LayoutParams(-1,dp(42)));
        explorerSearch.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){try{String q=s.toString().toLowerCase(Locale.ROOT);panelBody.removeViews(1,panelBody.getChildCount()-1);JSONObject rootObj=new JSONObject(NativeBridge.nativeHierarchyJson());addNodeFiltered(rootObj,0,q);}catch(Exception ignored){}}public void afterTextChanged(Editable e){}});
        try{JSONObject rootObj=new JSONObject(NativeBridge.nativeHierarchyJson());addNodeFiltered(rootObj,0,"");}catch(Exception e){panelBody.addView(label("Explorer parse error: "+e.getMessage()));}}
    private String spaces(int n){StringBuilder b=new StringBuilder();for(int i=0;i<Math.min(n,10);i++)b.append("  ");return b.toString();}
    private boolean treeMatches(JSONObject o,String q)throws JSONException{if(q.isEmpty())return true;String hay=(o.optString("name")+" "+o.optString("class")).toLowerCase(Locale.ROOT);if(hay.contains(q))return true;JSONArray c=o.optJSONArray("children");if(c!=null)for(int i=0;i<c.length();i++)if(treeMatches(c.getJSONObject(i),q))return true;return false;}
    private void addNodeFiltered(JSONObject o,int depth,String q)throws JSONException{if(!treeMatches(o,q))return;String id=o.optString("id"),name=o.optString("name"),cls=o.optString("class");JSONArray c=o.optJSONArray("children");boolean has=c!=null&&c.length()>0;LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);TextView arrow=label(has?(collapsed.contains(id)?"▸":"▾"):" ");arrow.setGravity(Gravity.CENTER);row.addView(arrow,new LinearLayout.LayoutParams(dp(24),dp(34)));TextView text=label(spaces(depth)+(depth==0?"":"• ")+name+"  <"+cls+">");text.setTextColor(id.equals(selectedId)?Color.WHITE:Color.LTGRAY);row.addView(text,new LinearLayout.LayoutParams(0,dp(34),1));row.setBackgroundColor(id.equals(selectedId)?Color.rgb(42,60,82):Color.TRANSPARENT);text.setOnClickListener(v->{selectedId=id;if(cls.endsWith("Script")){selectedScriptId=id;showPanel("SCRIPT EDITOR");}else showPanel("PROPERTIES");viewport.getEditorRenderer().refresh();});arrow.setOnClickListener(v->{if(has){if(collapsed.contains(id))collapsed.remove(id);else collapsed.add(id);buildExplorer();}});panelBody.addView(row,new LinearLayout.LayoutParams(-1,dp(34)));if(has&&!collapsed.contains(id))for(int i=0;i<c.length();i++)addNodeFiltered(c.getJSONObject(i),depth+1,q);}
    private void buildProperties(){
        panelTitle.setText("PROPERTIES");
        if(selectedId.isEmpty()){panelBody.addView(label("Nothing selected."));return;}
        try{JSONObject q=new JSONObject(NativeBridge.nativeGetProperties(selectedId));String cls=q.optString("class"),name=q.optString("name");panelBody.addView(label("Class: "+cls));addTextProp("Name",name);
            JSONObject p=q.getJSONObject("properties");String[] keys={"Position","Rotation","Size","Color","Material","Transparency","Reflectance","Anchored","CanCollide","CanTouch","CanQuery"};
            for(String k:keys)if(p.has(k))addTextProp(k,p.optString(k));
            Button dup=btn("DUPLICATE");dup.setOnClickListener(v->{selectedId=NativeBridge.nativeDuplicate(selectedId);refreshAll();showPanel("PROPERTIES");});panelBody.addView(dup);
            Button move=btn("MOVE / REPARENT");move.setOnClickListener(v->moveSelected());panelBody.addView(move);
            Button del=btn("DELETE");del.setOnClickListener(v->{NativeBridge.nativeDelete(selectedId);selectedId="";refreshAll();});panelBody.addView(del);
        }catch(Exception e){panelBody.addView(label("Property error: "+e.getMessage()));}
    }
    private void moveSelected(){if(selectedId.isEmpty())return;try{JSONObject rootObj=new JSONObject(NativeBridge.nativeHierarchyJson());ArrayList<String> names=new ArrayList<>(),ids=new ArrayList<>();collectMoveTargets(rootObj,names,ids);if(names.isEmpty()){showStatus("No valid parents");return;}new AlertDialog.Builder(this).setTitle("Move / Reparent").setItems(names.toArray(new String[0]),(d,w)->{if(NativeBridge.nativeMove(selectedId,ids.get(w))){refreshAll();showStatus("Moved to "+names.get(w));}else showStatus("Move rejected");}).show();}catch(Exception e){showStatus("Move error: "+e.getMessage());}}
    private void collectMoveTargets(JSONObject o,ArrayList<String> names,ArrayList<String> ids)throws JSONException{String id=o.optString("id"),cls=o.optString("class"),name=o.optString("name");if(!id.equals(selectedId)&&("DataModel".equals(cls)||"Workspace".equals(cls)||"Model".equals(cls)||"Folder".equals(cls)||"ReplicatedStorage".equals(cls)||"ServerScriptService".equals(cls)||"StarterGui".equals(cls)||"StarterPlayer".equals(cls)||"StarterPlayerScripts".equals(cls)||"Frame".equals(cls))) {names.add(name+" <"+cls+">");ids.add(id);}JSONArray c=o.optJSONArray("children");if(c!=null)for(int i=0;i<c.length();i++)collectMoveTargets(c.getJSONObject(i),names,ids);}
    private void addTextProp(String key,String value){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);TextView k=label(key);r.addView(k,new LinearLayout.LayoutParams(dp(105),dp(42)));EditText e=new EditText(this);e.setText(value);e.setTextColor(Color.WHITE);e.setTextSize(12);e.setSingleLine(true);e.setImeOptions(EditorInfo.IME_ACTION_DONE);e.setOnEditorActionListener((v,a,event)->{NativeBridge.nativeSetProperty(selectedId,key,v.getText().toString());viewport.getEditorRenderer().refresh();showStatus("Updated "+key);return false;});e.setOnFocusChangeListener((v,has)->{if(!has){NativeBridge.nativeSetProperty(selectedId,key,e.getText().toString());viewport.getEditorRenderer().refresh();}});r.addView(e,new LinearLayout.LayoutParams(0,dp(42),1));panelBody.addView(r);}
    private void buildOutput(){panelTitle.setText("OUTPUT");String json=lastOutput;try{JSONArray a=new JSONArray(json);if(a.length()==0)panelBody.addView(label("No runtime output yet."));for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);String line=o.optString("level")+" | "+o.optString("script")+(o.optInt("line",0)>0?" :"+o.optInt("line") : "")+" | "+o.optString("message");panelBody.addView(label(line));}}catch(Exception e){panelBody.addView(label(json));}}
    private void buildScriptEditor(){
        panelTitle.setText("SCRIPT EDITOR");
        LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);Button save=btn("SAVE SCRIPT"),find=btn("FIND"),replace=btn("REPLACE"),back=btn("EXPLORER");save.setOnClickListener(v->{if(!selectedScriptId.isEmpty()){NativeBridge.nativeSetSource(selectedScriptId,scriptEditor.getText().toString());showStatus("Script saved");}});find.setOnClickListener(v->scriptFind());replace.setOnClickListener(v->scriptReplace());back.setOnClickListener(v->showPanel("EXPLORER"));actions.addView(save,new LinearLayout.LayoutParams(0,dp(40),1));actions.addView(find,new LinearLayout.LayoutParams(0,dp(40),1));actions.addView(replace,new LinearLayout.LayoutParams(0,dp(40),1));actions.addView(back,new LinearLayout.LayoutParams(0,dp(40),1));panelBody.addView(actions);
        LinearLayout symbols=new LinearLayout(this);symbols.setOrientation(LinearLayout.HORIZONTAL);String[] syms={"()","[]","{}","=","->",":",";",".",",","_","end","local","function"};for(String sym:syms){Button sb=btn(sym);sb.setOnClickListener(v->{int pos=scriptEditor==null?0:scriptEditor.getSelectionStart();String add=((Button)v).getText().toString();if(add.equals("local"))add="local ";else if(add.equals("function"))add="function ";else if(add.equals("end"))add="end\n";if(scriptEditor!=null)scriptEditor.getText().insert(Math.max(0,pos),add);});symbols.addView(sb,new LinearLayout.LayoutParams(0,dp(38),1));}panelBody.addView(symbols,new LinearLayout.LayoutParams(-1,dp(40)));
        LinearLayout editor=new LinearLayout(this);editor.setOrientation(LinearLayout.HORIZONTAL);lineNumbers=new TextView(this);lineNumbers.setTextColor(Color.GRAY);lineNumbers.setTypeface(Typeface.MONOSPACE);lineNumbers.setText("1");lineNumbers.setGravity(Gravity.TOP|Gravity.RIGHT);lineNumbers.setPadding(0,dp(8),dp(8),0);editor.addView(lineNumbers,new LinearLayout.LayoutParams(dp(42),dp(420)));scriptEditor=new EditText(this);scriptEditor.setTypeface(Typeface.MONOSPACE);scriptEditor.setTextColor(Color.WHITE);scriptEditor.setTextSize(12);scriptEditor.setGravity(Gravity.TOP|Gravity.LEFT);scriptEditor.setSingleLine(false);scriptEditor.setBackgroundColor(Color.rgb(9,12,16));scriptEditor.setPadding(dp(8),dp(8),dp(8),dp(8));String source=selectedScriptId.isEmpty()?"":NativeBridge.nativeGetSource(selectedScriptId);scriptEditor.setText(source);editor.addView(scriptEditor,new LinearLayout.LayoutParams(0,dp(420),1));panelBody.addView(editor);scriptEditor.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){updateLines();highlight();}public void afterTextChanged(Editable e){}});updateLines();highlight();
    }
    private void scriptFind(){if(scriptEditor==null)return;final EditText q=new EditText(this);q.setHint("Find text");q.setSingleLine(true);new AlertDialog.Builder(this).setTitle("Find").setView(q).setPositiveButton("NEXT",(d,w)->{String needle=q.getText().toString();if(needle.isEmpty())return;String text=scriptEditor.getText().toString();int start=Math.max(0,scriptEditor.getSelectionEnd());int pos=text.indexOf(needle,start);if(pos<0)pos=text.indexOf(needle);if(pos>=0){scriptEditor.requestFocus();scriptEditor.setSelection(pos,pos+needle.length());}}).setNegativeButton("CLOSE",null).show();}
    private void scriptReplace(){if(scriptEditor==null)return;LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);EditText a=new EditText(this);a.setHint("Find");EditText b=new EditText(this);b.setHint("Replace with");box.addView(a);box.addView(b);new AlertDialog.Builder(this).setTitle("Replace").setView(box).setPositiveButton("REPLACE ALL",(d,w)->{String needle=a.getText().toString(),rep=b.getText().toString();if(needle.isEmpty())return;String text=scriptEditor.getText().toString();scriptEditor.setText(text.replace(needle,rep));showStatus("Replaced all occurrences");}).setNegativeButton("CLOSE",null).show();}
    private void updateLines(){if(lineNumbers==null||scriptEditor==null)return;int n=Math.max(1,scriptEditor.getText().toString().split("\\n",-1).length);StringBuilder b=new StringBuilder();for(int i=1;i<=n;i++){if(i>1)b.append('\n');b.append(i);}lineNumbers.setText(b.toString());}
    private void highlight(){if(scriptEditor==null)return;Editable e=scriptEditor.getText();String s=e.toString();e.setSpan(new ForegroundColorSpan(Color.WHITE),0,e.length(),0);Pattern kw=Pattern.compile("\\b(local|function|end|if|then|else|for|while|do|return|true|false|nil|and|or|not|require|print|warn)\\b");Matcher m=kw.matcher(s);while(m.find())e.setSpan(new ForegroundColorSpan(Color.rgb(120,170,255)),m.start(),m.end(),0);Pattern str=Pattern.compile("(\\\"[^\\\"]*\\\"|'[^']*')");m=str.matcher(s);while(m.find())e.setSpan(new ForegroundColorSpan(Color.rgb(135,210,150)),m.start(),m.end(),0);}
    private void runProject(){if(runtimeRunning){showStatus("PLAY already running");return;}runtimeRunning=true;progress.setVisibility(View.VISIBLE);io.execute(()->{String json=NativeBridge.nativeRun();lastOutput=json;runtimeRunning=false;runOnUiThread(()->{progress.setVisibility(View.GONE);sidePanel.setVisibility(View.VISIBLE);buildOutput();showStatus("PLAY finished");});});}
    private void saveLocal(){io.execute(()->{try{File f=new File(getFilesDir(),"project.rbxlx");try(FileOutputStream out=new FileOutputStream(f)){out.write(NativeBridge.nativeExportRbxlx().getBytes(StandardCharsets.UTF_8));}runOnUiThread(()->showStatus("Saved: "+f.getAbsolutePath()));}catch(Exception e){runOnUiThread(()->showStatus("Save error: "+e.getMessage()));}});}
    private void openImport(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,OPEN);}
    private void exportProject(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/xml");i.putExtra(Intent.EXTRA_TITLE,"LuauStudioProject.rbxlx");startActivityForResult(i,EXPORT);}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(res!=RESULT_OK||data==null)return;Uri u=data.getData();if(req==OPEN)importUri(u);else exportUri(u);}
    private String readUri(Uri u)throws Exception{InputStream in=getContentResolver().openInputStream(u);if(in==null)throw new IOException("Cannot open selected file");ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;long total=0;final long MAX=128L*1024L*1024L;while((n=in.read(buf))>0){total+=n;if(total>MAX){in.close();throw new IOException("Project too large for mobile safe import (128 MB limit)");}b.write(buf,0,n);}in.close();return b.toString("UTF-8");}
    private void importUri(Uri u){progress.setVisibility(View.VISIBLE);io.execute(()->{try{String xml=readUri(u);String r=NativeBridge.nativeImportRbxlx(xml);runOnUiThread(()->{progress.setVisibility(View.GONE);showStatus("Imported • "+r);refreshAll();});}catch(Exception e){runOnUiThread(()->{progress.setVisibility(View.GONE);showStatus("Import error: "+e.getMessage());});}});}
    private void exportUri(Uri u){io.execute(()->{try{String xml=NativeBridge.nativeExportRbxlx();OutputStream out=getContentResolver().openOutputStream(u);out.write(xml.getBytes(StandardCharsets.UTF_8));out.close();runOnUiThread(()->showStatus("Exported RBXLX"));}catch(Exception e){runOnUiThread(()->showStatus("Export error: "+e.getMessage()));}});}
    @Override protected void onDestroy(){super.onDestroy();io.shutdownNow();}
}
