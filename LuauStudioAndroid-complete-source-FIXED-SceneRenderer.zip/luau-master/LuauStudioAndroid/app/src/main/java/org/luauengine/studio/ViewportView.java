package org.luauengine.studio;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;

public class ViewportView extends GLSurfaceView {
    private final SceneRenderer renderer;
    public ViewportView(Context context) {
        super(context);
        setEGLContextClientVersion(3);
        renderer = new SceneRenderer();
        setRenderer(renderer);
        setRenderMode(RENDERMODE_CONTINUOUSLY);
    }
    public SceneRenderer getEditorRenderer(){ return renderer; }
    @Override public boolean onTouchEvent(MotionEvent event){
        renderer.onTouch(event);
        return true;
    }
}
