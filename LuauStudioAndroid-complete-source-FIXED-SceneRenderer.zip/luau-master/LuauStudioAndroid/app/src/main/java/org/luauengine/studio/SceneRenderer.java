package org.luauengine.studio;

import android.opengl.GLES30;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.view.MotionEvent;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;
import org.json.JSONArray;
import org.json.JSONObject;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class SceneRenderer implements GLSurfaceView.Renderer {
    public interface SelectionListener { void onSelected(String id); }
    static class Part { String id,name,shape; float[] p={0,0,0},s={1,1,1},c={.6f,.6f,.6f},r={0,0,0}; }
    static class Mesh { final FloatBuffer vertices; final int count; Mesh(float[] v){vertices=buffer(v);count=v.length/3;} }
    private final List<Part> parts=new ArrayList<>();
    private SelectionListener listener;
    private String selectedId="", tool="SELECT";
    private int program,width,height,maxObjects=1500;
    private Mesh cube,sphere,cylinder,wedge,corner,grid,lineCube;
    private final float[] proj=new float[16],view=new float[16],model=new float[16],mvp=new float[16],vp=new float[16];
    private float yaw=35f,pitch=22f,distance=45f;
    private float lastX,lastY,lastPinch;
    private boolean draggingObject=false;

    public SceneRenderer(){cube=makeCube();sphere=makeSphere();cylinder=makeCylinder();wedge=makeWedge();corner=makeCornerWedge();grid=makeGrid(24,2f);lineCube=makeLineCube();}
    private static FloatBuffer buffer(float[] a){ByteBuffer b=ByteBuffer.allocateDirect(a.length*4).order(ByteOrder.nativeOrder());FloatBuffer f=b.asFloatBuffer();f.put(a).position(0);return f;}
    private static void tri(List<Float> v,float ax,float ay,float az,float bx,float by,float bz,float cx,float cy,float cz){v.add(ax);v.add(ay);v.add(az);v.add(bx);v.add(by);v.add(bz);v.add(cx);v.add(cy);v.add(cz);}
    private Mesh makeCube(){List<Float>v=new ArrayList<>();float[][]q={{-1,-1,-1,1,-1,-1,1,1,-1,-1,1,-1},{-1,-1,1,-1,1,1,1,1,1,1,-1,1},{-1,-1,-1,-1,1,-1,-1,1,1,-1,-1,1},{1,-1,-1,1,-1,1,1,1,1,1,1,-1},{-1,-1,-1,-1,-1,1,1,-1,1,1,-1,-1},{-1,1,-1,1,1,-1,1,1,1,-1,1,1}};for(float[]a:q){tri(v,a[0],a[1],a[2],a[3],a[4],a[5],a[6],a[7],a[8]);tri(v,a[0],a[1],a[2],a[6],a[7],a[8],a[9],a[10],a[11]);}float[]x=new float[v.size()];for(int i=0;i<x.length;i++)x[i]=v.get(i);return new Mesh(x);}
    private Mesh makeSphere(){List<Float>v=new ArrayList<>();int lat=12,lon=20;for(int a=0;a<lat;a++){double p0=Math.PI*(-0.5+(double)a/lat),p1=Math.PI*(-0.5+(double)(a+1)/lat);for(int b=0;b<lon;b++){double t0=2*Math.PI*b/lon,t1=2*Math.PI*(b+1)/lon;float[] A={(float)(Math.cos(p0)*Math.cos(t0)),(float)Math.sin(p0),(float)(Math.cos(p0)*Math.sin(t0))};float[] B={(float)(Math.cos(p1)*Math.cos(t0)),(float)Math.sin(p1),(float)(Math.cos(p1)*Math.sin(t0))};float[] C={(float)(Math.cos(p1)*Math.cos(t1)),(float)Math.sin(p1),(float)(Math.cos(p1)*Math.sin(t1))};float[]D={(float)(Math.cos(p0)*Math.cos(t1)),(float)Math.sin(p0),(float)(Math.cos(p0)*Math.sin(t1))};tri(v,A[0],A[1],A[2],B[0],B[1],B[2],C[0],C[1],C[2]);tri(v,A[0],A[1],A[2],C[0],C[1],C[2],D[0],D[1],D[2]);}}float[]x=new float[v.size()];for(int i=0;i<x.length;i++)x[i]=v.get(i);return new Mesh(x);}
    private Mesh makeCylinder(){List<Float>v=new ArrayList<>();int n=24;for(int i=0;i<n;i++){double a0=2*Math.PI*i/n,a1=2*Math.PI*(i+1)/n;float x0=(float)Math.cos(a0),z0=(float)Math.sin(a0),x1=(float)Math.cos(a1),z1=(float)Math.sin(a1);tri(v,x0,-1,z0,x1,-1,z1,x1,1,z1);tri(v,x0,-1,z0,x1,1,z1,x0,1,z0);tri(v,0,1,0,x1,1,z1,x0,1,z0);tri(v,0,-1,0,x0,-1,z0,x1,-1,z1);}float[]x=new float[v.size()];for(int i=0;i<x.length;i++)x[i]=v.get(i);return new Mesh(x);}
    private Mesh makeWedge(){float[]v={-1,-1,-1,1,-1,-1,1,-1,1,-1,-1,-1,1,-1,1,-1,1,-1,1,1,-1,-1,-1,-1,1,-1,1,1,1,-1,-1,-1,-1,1,1,-1,1,1,-1,1,-1,1,-1,-1, -1,-1,-1,-1,1,-1,1,1,-1, -1,-1,-1,1,-1,1,1,1,-1, -1,-1,-1,1,1,-1,-1,1,-1, -1,-1,1,1,1,-1,1,-1,1, -1,-1,1,1,1,-1,-1,1,-1};return new Mesh(v);}
    private Mesh makeCornerWedge(){float[]v={-1,-1,-1,1,-1,-1,-1,-1,1,-1,-1,-1,-1,-1,1,-1,1,1,-1,-1,-1,-1,1,1,-1,1,1, -1,-1,-1,1,-1,-1,-1,1,1, 1,-1,-1,1,-1,1,1,1,1, -1,-1,-1,-1,1,1,1,1,1, -1,-1,-1,1,1,1,1,-1,-1, -1,-1,1,1,-1,1,1,1,1};return new Mesh(v);}
    private Mesh makeLineCube(){float[]v={-1,-1,-1,1,-1,-1, 1,-1,-1,1,1,-1, 1,1,-1,-1,1,-1, -1,1,-1,-1,-1,-1, -1,-1,1,1,-1,1, 1,-1,1,1,1,1, 1,1,1,-1,1,1, -1,1,1,-1,-1,1, -1,-1,-1,-1,-1,1, 1,-1,-1,1,-1,1, 1,1,-1,1,1,1, -1,1,-1,-1,1,1};return new Mesh(v);}
    private Mesh makeGrid(int n,float step){List<Float>v=new ArrayList<>();for(int i=-n;i<=n;i++){float d=i*step;v.add(-n*step);v.add(0f);v.add(d);v.add(n*step);v.add(0f);v.add(d);v.add(d);v.add(0f);v.add(-n*step);v.add(d);v.add(0f);v.add(n*step);}float[]x=new float[v.size()];for(int i=0;i<x.length;i++)x[i]=v.get(i);return new Mesh(x);}

    public void setSelectionListener(SelectionListener l){listener=l;}
    public void setTool(String t){tool=t;}
    public void setQuality(String q){maxObjects=q.equals("LOW-END")?600:q.equals("BALANCED")?1500:3000;}
    public void refresh(){String json=NativeBridge.nativeSceneJson();synchronized(parts){parts.clear();try{JSONArray a=new JSONArray(json);for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);Part p=new Part();p.id=o.getString("id");p.name=o.optString("name",p.id);p.shape=o.optString("shape","Block");parse3(o.optString("pos","0,0,0"),p.p);parse3(o.optString("size","4,4,4"),p.s);parse3(o.optString("color","0.6,0.6,0.6"),p.c);parse3(o.optString("rot","0,0,0"),p.r);parts.add(p);}}catch(Exception ignored){}}}
    private static void parse3(String s,float[]o){try{String[]q=s.split(",");for(int i=0;i<3&&i<q.length;i++)o[i]=Float.parseFloat(q[i].trim());}catch(Exception ignored){}}
    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        GLES30.glClearColor(.035f, .045f, .065f, 1.0f);
        GLES30.glEnable(GLES30.GL_DEPTH_TEST);
        program = makeProgram();
        refresh();
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int w, int h) {
        width = w;
        height = h;
        GLES30.glViewport(0, 0, w, h);
        float aspect = h > 0 ? (float) w / (float) h : 1.0f;
        Matrix.perspectiveM(proj, 0, 55f, Math.max(1f, aspect), .1f, 500f);
    }
    @Override public void onDrawFrame(javax.microedition.khronos.opengles.GL10 gl){GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT|GLES30.GL_DEPTH_BUFFER_BIT);float yr=(float)Math.toRadians(yaw),pr=(float)Math.toRadians(pitch);float cx=(float)(Math.cos(pr)*Math.sin(yr)*distance),cy=(float)(Math.sin(pr)*distance)+4f,cz=(float)(Math.cos(pr)*Math.cos(yr)*distance);Matrix.setLookAtM(view,0,cx,cy,cz,0,2,0,0,1,0);Matrix.multiplyMM(vp,0,proj,0,view,0);int aPos=GLES30.glGetAttribLocation(program,"aPosition"),uMvp=GLES30.glGetUniformLocation(program,"uMVP"),uColor=GLES30.glGetUniformLocation(program,"uColor");
        drawLines(grid,0,0,0,1,1,1,uMvp,aPos,uColor,0.15f);
        synchronized(parts){int rendered=0;for(Part p:parts){if(rendered++>=maxObjects)break;Matrix.setIdentityM(model,0);Matrix.translateM(model,0,p.p[0],p.p[1],p.p[2]);Matrix.rotateM(model,0,p.r[1],0,1,0);Matrix.rotateM(model,0,p.r[0],1,0,0);Matrix.rotateM(model,0,p.r[2],0,0,1);Matrix.scaleM(model,0,p.s[0]/2f,p.s[1]/2f,p.s[2]/2f);Matrix.multiplyMM(mvp,0,vp,0,model,0);GLES30.glUniformMatrix4fv(uMvp,1,false,mvp,0);float b=p.id.equals(selectedId)?1.35f:1f;GLES30.glUniform4f(uColor,Math.min(1,p.c[0]*b),Math.min(1,p.c[1]*b),Math.min(1,p.c[2]*b),1);GLES30.glEnableVertexAttribArray(aPos);GLES30.glVertexAttribPointer(aPos,3,GLES30.GL_FLOAT,false,0,meshFor(p.shape).vertices);GLES30.glDrawArrays(GLES30.GL_TRIANGLES,0,meshFor(p.shape).count);GLES30.glDisableVertexAttribArray(aPos);if(p.id.equals(selectedId))drawSelectionBox(p,aPos,uMvp,uColor);}}
    }
    private Mesh meshFor(String shape){switch(shape){case"Sphere":return sphere;case"Cylinder":return cylinder;case"Wedge":return wedge;case"CornerWedge":return corner;default:return cube;}}
    private void drawSelectionBox(Part p,int aPos,int uMvp,int uColor){GLES30.glEnable(GLES30.GL_BLEND);GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA,GLES30.GL_ONE_MINUS_SRC_ALPHA);Matrix.setIdentityM(model,0);Matrix.translateM(model,0,p.p[0],p.p[1],p.p[2]);Matrix.scaleM(model,0,p.s[0]/2f+0.06f,p.s[1]/2f+0.06f,p.s[2]/2f+0.06f);Matrix.multiplyMM(mvp,0,vp,0,model,0);GLES30.glUniformMatrix4fv(uMvp,1,false,mvp,0);GLES30.glUniform4f(uColor,1,1,1,.55f);GLES30.glEnableVertexAttribArray(aPos);GLES30.glVertexAttribPointer(aPos,3,GLES30.GL_FLOAT,false,0,lineCube.vertices);GLES30.glDrawArrays(GLES30.GL_LINES,0,lineCube.count);GLES30.glDisableVertexAttribArray(aPos);GLES30.glDisable(GLES30.GL_BLEND);}
    private void drawLines(Mesh m,int x,int y,int z,float r,float g,float b,int uMvp,int aPos,int uColor,float alpha){Matrix.setIdentityM(model,0);Matrix.translateM(model,0,x,y,z);Matrix.multiplyMM(mvp,0,vp,0,model,0);GLES30.glUniformMatrix4fv(uMvp,1,false,mvp,0);GLES30.glUniform4f(uColor,r,g,b,alpha);GLES30.glEnableVertexAttribArray(aPos);GLES30.glVertexAttribPointer(aPos,3,GLES30.GL_FLOAT,false,0,m.vertices);GLES30.glDrawArrays(GLES30.GL_LINES,0,m.count);GLES30.glDisableVertexAttribArray(aPos);}
    private int makeProgram(){String vs="#version 300 es\nin vec3 aPosition;uniform mat4 uMVP;void main(){gl_Position=uMVP*vec4(aPosition,1.0);}";String fs="#version 300 es\nprecision mediump float;uniform vec4 uColor;out vec4 frag;void main(){frag=uColor;}";int v=compile(GLES30.GL_VERTEX_SHADER,vs),f=compile(GLES30.GL_FRAGMENT_SHADER,fs),p=GLES30.glCreateProgram();GLES30.glAttachShader(p,v);GLES30.glAttachShader(p,f);GLES30.glLinkProgram(p);return p;}
    private int compile(int t,String s){int x=GLES30.glCreateShader(t);GLES30.glShaderSource(x,s);GLES30.glCompileShader(x);return x;}
    public void onTouch(MotionEvent e){int act=e.getActionMasked();if(act==MotionEvent.ACTION_DOWN){lastX=e.getX();lastY=e.getY();draggingObject=selectedId.length()>0&&(tool.equals("MOVE")||tool.equals("ROTATE")||tool.equals("SCALE"));}else if(act==MotionEvent.ACTION_POINTER_DOWN&&e.getPointerCount()>=2){lastPinch=dist(e);}else if(act==MotionEvent.ACTION_MOVE){if(e.getPointerCount()>=2){float d=dist(e);distance=Math.max(6,Math.min(180,distance-(d-lastPinch)*.08f));lastPinch=d;return;}float x=e.getX(),y=e.getY(),dx=x-lastX,dy=y-lastY;if(draggingObject)applyObjectDrag(dx,dy);else{yaw+=dx*.25f;pitch=Math.max(-75,Math.min(75,pitch-dy*.2f));}lastX=x;lastY=y;}else if(act==MotionEvent.ACTION_UP){if(!draggingObject||Math.hypot(e.getX()-lastX,e.getY()-lastY)<8)pick(e.getX(),e.getY());draggingObject=false;}}
    private float dist(MotionEvent e){if(e.getPointerCount()<2)return 0;float dx=e.getX(0)-e.getX(1),dy=e.getY(0)-e.getY(1);return(float)Math.sqrt(dx*dx+dy*dy);}
    private Part find(String id){synchronized(parts){for(Part p:parts)if(p.id.equals(id))return p;}return null;}
    private void applyObjectDrag(float dx,float dy){Part p=find(selectedId);if(p==null)return;float k=distance/Math.max(200,height);if(tool.equals("MOVE")){float yr=(float)Math.toRadians(yaw);p.p[0]+=(float)Math.cos(yr)*dx*k;p.p[2]-=(float)Math.sin(yr)*dx*k;p.p[1]-=dy*k;set3("Position",p.p);}else if(tool.equals("ROTATE")){p.r[1]+=dx*.7f;set3("Rotation",p.r);}else{float v=Math.max(.2f,1f+dy*.01f);p.s[0]=Math.max(.2f,p.s[0]*v);p.s[1]=Math.max(.2f,p.s[1]*v);p.s[2]=Math.max(.2f,p.s[2]*v);set3("Size",p.s);}}
    private void set3(String k,float[]v){NativeBridge.nativeSetProperty(selectedId,k,String.format(Locale.US,"%.4f,%.4f,%.4f",v[0],v[1],v[2]));}
    private void pick(float sx,float sy){Part best=null;float bd=85*85;synchronized(parts){for(Part p:parts){float[]w={p.p[0],p.p[1],p.p[2],1},c={0,0,0,0};Matrix.multiplyMV(c,0,vp,0,w,0);if(Math.abs(c[3])<.001)continue;float px=(c[0]/c[3]*.5f+.5f)*width,py=(1-(c[1]/c[3]*.5f+.5f))*height,dd=(px-sx)*(px-sx)+(py-sy)*(py-sy);if(dd<bd){bd=dd;best=p;}}}selectedId=best==null?"":best.id;if(listener!=null)listener.onSelected(selectedId);}
}
