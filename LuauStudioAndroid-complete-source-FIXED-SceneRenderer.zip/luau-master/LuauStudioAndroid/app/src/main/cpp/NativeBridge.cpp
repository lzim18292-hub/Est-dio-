#include <jni.h>
#include <string>
#include <sstream>
#include <vector>
#include <memory>
#include <algorithm>
#include <mutex>
#include "../../../../engine/core/Instance.h"
#include "../../../../engine/serialization/Rbxlx.h"
#include "../../../../engine/runtime/LuauRuntime.h"

using namespace Studio;
static DataModel gModel;
static LuauRuntime gRuntime;
static std::mutex gNativeMutex;
static std::shared_ptr<Instance> get(const std::string& id){ return gModel.findById(id); }
static jstring js(JNIEnv* env,const std::string& s){return env->NewStringUTF(s.c_str());}
static std::string jss(JNIEnv* env,jstring s){if(!s)return{};const char*p=env->GetStringUTFChars(s,nullptr);std::string out=p?p:"";if(p)env->ReleaseStringUTFChars(s,p);return out;}
static std::string jsonEscape(const std::string&s){std::string o;for(char c:s){if(c=='\\')o+="\\\\";else if(c=='"')o+="\\\"";else if(c=='\n')o+="\\n";else o+=c;}return o;}

extern "C" JNIEXPORT void JNICALL Java_org_luauengine_studio_NativeBridge_nativeInit(JNIEnv*,jclass){ std::lock_guard<std::mutex> l(gNativeMutex); gModel.reset(); }
extern "C" JNIEXPORT void JNICALL Java_org_luauengine_studio_NativeBridge_nativeNewProject(JNIEnv*,jclass){ std::lock_guard<std::mutex> l(gNativeMutex); gModel.reset(); }
extern "C" JNIEXPORT jstring JNICALL Java_org_luauengine_studio_NativeBridge_nativeSceneJson(JNIEnv*e,jclass){ std::lock_guard<std::mutex> l(gNativeMutex); return js(e,gModel.sceneJson()); }
extern "C" JNIEXPORT jstring JNICALL Java_org_luauengine_studio_NativeBridge_nativeHierarchyJson(JNIEnv*e,jclass){ std::lock_guard<std::mutex> l(gNativeMutex); return js(e,gModel.hierarchyJson()); }
extern "C" JNIEXPORT jint JNICALL Java_org_luauengine_studio_NativeBridge_nativeObjectCount(JNIEnv*,jclass){ std::lock_guard<std::mutex> l(gNativeMutex); return (jint)gModel.objectCount(); }
extern "C" JNIEXPORT jstring JNICALL Java_org_luauengine_studio_NativeBridge_nativeCreatePart(JNIEnv*e,jclass,jstring shape){ std::lock_guard<std::mutex> l(gNativeMutex); auto p=gModel.addPart(jss(e,shape)); return js(e,p?p->referent:""); }
extern "C" JNIEXPORT jstring JNICALL Java_org_luauengine_studio_NativeBridge_nativeCreateObject(JNIEnv*e,jclass,jstring cls,jstring parent){ std::lock_guard<std::mutex> l(gNativeMutex); auto p=gModel.addObject(jss(e,cls),jss(e,parent)); return js(e,p?p->referent:""); }
extern "C" JNIEXPORT jstring JNICALL Java_org_luauengine_studio_NativeBridge_nativeDuplicate(JNIEnv*e,jclass,jstring id){ std::lock_guard<std::mutex> l(gNativeMutex); auto p=gModel.duplicate(get(jss(e,id))); return js(e,p?p->referent:""); }
extern "C" JNIEXPORT jboolean JNICALL Java_org_luauengine_studio_NativeBridge_nativeMove(JNIEnv*e,jclass,jstring id,jstring parent){ std::lock_guard<std::mutex> l(gNativeMutex); auto obj=gModel.findById(jss(e,id)); auto dst=gModel.findById(jss(e,parent)); return gModel.moveInstance(obj,dst)?JNI_TRUE:JNI_FALSE; }
extern "C" JNIEXPORT jboolean JNICALL Java_org_luauengine_studio_NativeBridge_nativeDelete(JNIEnv*e,jclass,jstring id){ std::lock_guard<std::mutex> l(gNativeMutex); return gModel.deleteInstance(get(jss(e,id)))?JNI_TRUE:JNI_FALSE; }
extern "C" JNIEXPORT jboolean JNICALL Java_org_luauengine_studio_NativeBridge_nativeSetProperty(JNIEnv*e,jclass,jstring id,jstring key,jstring value){ std::lock_guard<std::mutex> l(gNativeMutex); return gModel.setProperty(jss(e,id),jss(e,key),jss(e,value))?JNI_TRUE:JNI_FALSE; }
extern "C" JNIEXPORT jstring JNICALL Java_org_luauengine_studio_NativeBridge_nativeGetProperties(JNIEnv*e,jclass,jstring id){ std::lock_guard<std::mutex> l(gNativeMutex); return js(e,gModel.getPropertiesJson(jss(e,id))); }
extern "C" JNIEXPORT jstring JNICALL Java_org_luauengine_studio_NativeBridge_nativeGetSource(JNIEnv*e,jclass,jstring id){ std::lock_guard<std::mutex> l(gNativeMutex); return js(e,gModel.getSource(jss(e,id))); }
extern "C" JNIEXPORT jstring JNICALL Java_org_luauengine_studio_NativeBridge_nativeSetSource(JNIEnv*e,jclass,jstring id,jstring source){ std::lock_guard<std::mutex> l(gNativeMutex); return js(e,gModel.setSource(jss(e,id),jss(e,source))?"ok":"error: object not found"); }
extern "C" JNIEXPORT void JNICALL Java_org_luauengine_studio_NativeBridge_nativeStop(JNIEnv*,jclass){ std::lock_guard<std::mutex> l(gNativeMutex); gRuntime.requestStop(); }
extern "C" JNIEXPORT jstring JNICALL Java_org_luauengine_studio_NativeBridge_nativeRun(JNIEnv*e,jclass){ std::lock_guard<std::mutex> l(gNativeMutex); auto lines=gRuntime.run(gModel);std::ostringstream o;o<<"[";for(size_t i=0;i<lines.size();++i){if(i)o<<',';o<<"{\"level\":\""<<jsonEscape(lines[i].level)<<"\",\"script\":\""<<jsonEscape(lines[i].script)<<"\",\"message\":\""<<jsonEscape(lines[i].message)<<"\",\"line\":"<<lines[i].line<<"}";}o<<"]";return js(e,o.str());}
extern "C" JNIEXPORT jstring JNICALL Java_org_luauengine_studio_NativeBridge_nativeImportRbxlx(JNIEnv*e,jclass,jstring xml){ std::lock_guard<std::mutex> l(gNativeMutex); std::string data=jss(e,xml);auto r=RbxlxCodec::importXml(data,gModel);std::ostringstream o;o<<"{\"ok\":"<<(r.ok?"true":"false")<<",\"instances\":"<<r.instances<<",\"unknown\":"<<r.unknown<<",\"error\":\""<<jsonEscape(r.error)<<"\"}";return js(e,o.str());}
extern "C" JNIEXPORT jstring JNICALL Java_org_luauengine_studio_NativeBridge_nativeExportRbxlx(JNIEnv*e,jclass){ std::lock_guard<std::mutex> l(gNativeMutex); return js(e,RbxlxCodec::exportXml(gModel)); }
