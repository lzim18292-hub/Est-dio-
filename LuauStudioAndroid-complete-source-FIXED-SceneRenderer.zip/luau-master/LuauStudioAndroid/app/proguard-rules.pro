# Luau Studio uses JNI names referenced from Java; keep native declarations.
-keep class org.luauengine.studio.NativeBridge { *; }
