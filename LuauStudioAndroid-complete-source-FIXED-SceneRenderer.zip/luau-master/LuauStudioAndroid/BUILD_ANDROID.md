# Build Android ARM64

## Android Studio

The Android build settings follow the Android Gradle Plugin 8.13 compatibility matrix: Gradle 8.13, SDK Build Tools 35.0.0 and JDK 17 are the supported/default combination. The project pins the latest LTS NDK r27d (`27.3.13750724`) for reproducible ARM64 builds.

Open the `LuauStudioAndroid` directory as an Android Studio project.

Recommended SDK components:
- Android SDK Platform 36
- Android SDK Build-Tools 35.0.0
- Android NDK r27d / `27.3.13750724`
- CMake 3.22.1
- JDK 17+

Then run `app -> assembleDebug` or Android Studio's Build APK action.

## Command line

This source tree intentionally keeps the official Luau source at the repository root and adds the Android project under `LuauStudioAndroid/`.

From an environment with Gradle 8.13 and the Android SDK installed:

```bash
gradle -p LuauStudioAndroid :app:assembleDebug
```

Expected artifact:

```text
LuauStudioAndroid/app/build/outputs/apk/debug/app-debug.apk
```

The configured application ABI is `arm64-v8a`.

## Why the APK is not included in this workspace

The build container used for this delivery has CMake/Ninja and a full C++ toolchain, but it does not contain the Android SDK, Android Build-Tools, or Android NDK. DNS/network access from the build container is also unavailable, so the Android toolchain could not be installed here. The native Luau/core tests were nevertheless compiled and executed on the host.
