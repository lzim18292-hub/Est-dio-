#pragma once
#include "../core/Instance.h"
#include <string>
#include <vector>
#include <atomic>

struct lua_State;

namespace Studio {
struct OutputLine { std::string level, script, message; int line=0; };
class LuauRuntime {
public:
    std::vector<OutputLine> run(DataModel& model);
    void requestStop();
private:
    std::vector<OutputLine> output_;
    static int l_print(lua_State* L);
    static int l_warn(lua_State* L);
    static std::string valueToString(lua_State* L,int idx);
    void append(const char* level,const std::string& script,const std::string& message,int line=0);
    bool runScript(const std::shared_ptr<Instance>& inst);
    std::atomic<bool> stopRequested_{false};
};
}
