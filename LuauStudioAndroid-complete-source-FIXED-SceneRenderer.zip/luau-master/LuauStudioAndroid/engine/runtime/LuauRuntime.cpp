#include "LuauRuntime.h"
#include <sstream>
#include <mutex>
#include "../../VM/include/lua.h"
#include "../../VM/include/lualib.h"
#include "../../Compiler/include/Luau/Compiler.h"

namespace Studio {
static std::mutex gRtMutex;
static thread_local std::string gScriptName;
static thread_local std::vector<OutputLine>* gOutput=nullptr;
std::string LuauRuntime::valueToString(lua_State*L,int idx){size_t n=0;const char*s=lua_tolstring(L,idx,&n);if(s)return std::string(s,n);int t=lua_type(L,idx);if(t==LUA_TNIL)return "nil";if(t==LUA_TBOOLEAN)return lua_toboolean(L,idx)?"true":"false";if(t==LUA_TNUMBER)return std::to_string(lua_tonumberx(L,idx,nullptr));return std::string(lua_typename(L,t));}
int LuauRuntime::l_print(lua_State*L){std::ostringstream o;for(int i=1;i<=lua_gettop(L);++i){if(i>1)o<<"\t";o<<valueToString(L,i);}if(gOutput)gOutput->push_back({"PRINT",gScriptName,o.str(),0});return 0;}
int LuauRuntime::l_warn(lua_State*L){std::ostringstream o;for(int i=1;i<=lua_gettop(L);++i){if(i>1)o<<"\t";o<<valueToString(L,i);}if(gOutput)gOutput->push_back({"WARNING",gScriptName,o.str(),0});return 0;}
void LuauRuntime::append(const char*level,const std::string&s,const std::string&m,int line){output_.push_back({level,s,m,line});}
void LuauRuntime::requestStop(){ stopRequested_.store(true); }
bool LuauRuntime::runScript(const std::shared_ptr<Instance>& inst){
    if(inst->source.empty()) return true;
    lua_State* L=luaL_newstate(); if(!L){append("ERROR",inst->name,"Unable to allocate Luau VM");return false;}
    // Deliberately expose only deterministic standard libraries; no OS/filesystem access.
    luaopen_base(L); luaopen_table(L); luaopen_string(L); luaopen_math(L); luaopen_utf8(L); luaopen_buffer(L); luaopen_coroutine(L); luaopen_vector(L);
    gScriptName=inst->name;gOutput=&output_;
    lua_pushcfunction(L,&LuauRuntime::l_print,"print");lua_setglobal(L,"print");
    lua_pushcfunction(L,&LuauRuntime::l_warn,"warn");lua_setglobal(L,"warn");
    lua_pushstring(L,inst->name.c_str());lua_setglobal(L,"script");
    lua_pushstring(L,"StudioWorkspace");lua_setglobal(L,"workspace");
    try{
        Luau::CompileOptions options; options.optimizationLevel=1; options.debugLevel=2; std::string bytecode=Luau::compile(inst->source,options);
        int status=luau_load(L,inst->name.c_str(),bytecode.data(),bytecode.size(),0); if(status!=0){size_t n=0;const char*s=lua_tolstring(L,-1,&n);append(status==LUA_ERRSYNTAX?"ERROR":"ERROR",inst->name,s?std::string(s,n):"bytecode load error",0);lua_close(L);gOutput=nullptr;return false;}
        status=lua_pcall(L,0,0,0); if(status!=LUA_OK){size_t n=0;const char*s=lua_tolstring(L,-1,&n);append("ERROR",inst->name,s?std::string(s,n):"runtime error",0);lua_close(L);gOutput=nullptr;return false;}
    }catch(const Luau::CompileError&e){append("ERROR",inst->name,e.what(),int(e.getLocation().begin.line)+1);lua_close(L);gOutput=nullptr;return false;}catch(const std::exception&e){append("ERROR",inst->name,e.what(),0);lua_close(L);gOutput=nullptr;return false;}
    lua_close(L);gOutput=nullptr;return true;
}
std::vector<OutputLine> LuauRuntime::run(DataModel& model){
    std::lock_guard<std::mutex> lock(gRtMutex);
    output_.clear();
    stopRequested_.store(false);
    append("INFO","Runtime","Play started");
    bool ok=true;
    for(const auto& inst: model.scriptSnapshot()){
        if(stopRequested_.load()){
            append("WARNING","Runtime","Stop requested");
            break;
        }
        // ModuleScripts are preserved by the editor and can later be required by a richer runtime.
        // The first production-safe runtime intentionally executes only Script/LocalScript entries.
        if(inst->className=="Script"||inst->className=="LocalScript") ok=runScript(inst)&&ok;
    }
    if(stopRequested_.load()) append("WARNING","Runtime","Play stopped between scripts");
    else append(ok?"INFO":"ERROR","Runtime",ok?"Play finished":"Play finished with errors");
    return output_;
}
}
