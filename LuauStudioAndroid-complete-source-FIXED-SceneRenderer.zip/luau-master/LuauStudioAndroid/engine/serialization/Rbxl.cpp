#include "Rbxl.h"
namespace Studio {
RbxlBinaryResult RbxlBinaryCodec::importBinary(const std::string&, DataModel&){ return {false, "Binary .rbxl is not implemented yet; use .rbxlx."}; }
RbxlBinaryResult RbxlBinaryCodec::exportBinary(const DataModel&, std::string&){ return {false, "Binary .rbxl export is not implemented yet; use .rbxlx."}; }
}
