#pragma once
#include "../core/Instance.h"
#include <string>

namespace Studio {
struct RbxlBinaryResult { bool ok=false; std::string error; };
class RbxlBinaryCodec {
public:
    // Binary .rbxl uses a different serialization layer. This interface keeps
    // it isolated from the working RBXLX codec so the editor can add support
    // without changing the DataModel/import UI contract.
    static RbxlBinaryResult importBinary(const std::string& bytes, DataModel& model);
    static RbxlBinaryResult exportBinary(const DataModel& model, std::string& bytes);
};
}
