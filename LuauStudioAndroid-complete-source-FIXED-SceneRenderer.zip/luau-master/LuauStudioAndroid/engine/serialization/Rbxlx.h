#pragma once
#include "../core/Instance.h"
#include <string>
#include <vector>

namespace Studio {
struct RbxlxResult { bool ok=false; std::string error; size_t instances=0; size_t unknown=0; };
class RbxlxCodec {
public:
    static RbxlxResult importXml(const std::string& xml, DataModel& model);
    static std::string exportXml(const DataModel& model);
};
}
