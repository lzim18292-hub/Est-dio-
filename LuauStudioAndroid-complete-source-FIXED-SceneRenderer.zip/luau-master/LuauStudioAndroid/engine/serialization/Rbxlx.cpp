#include "Rbxlx.h"
#include <map>
#include <sstream>
#include <algorithm>
#include <cctype>
#include <functional>
#include <cstring>
#include <cmath>
#include <iomanip>

namespace Studio {
namespace {

struct Node
{
    std::string name;
    std::string text;
    std::map<std::string, std::string> attrs;
    std::vector<Node> children;
};

static std::string unescape(const std::string& s)
{
    std::string o = s;
    auto rep = [&](const char* a, const char* b)
    {
        size_t p = 0;
        while ((p = o.find(a, p)) != std::string::npos)
        {
            o.replace(p, std::strlen(a), b);
            p += std::strlen(b);
        }
    };
    rep("&quot;", "\"");
    rep("&apos;", "'");
    rep("&lt;", "<");
    rep("&gt;", ">");
    rep("&amp;", "&");
    return o;
}

static std::string esc(const std::string& s)
{
    std::string o;
    o.reserve(s.size() + 8);
    for (char c : s)
    {
        if (c == '&') o += "&amp;";
        else if (c == '<') o += "&lt;";
        else if (c == '>') o += "&gt;";
        else if (c == '\"') o += "&quot;";
        else o += c;
    }
    return o;
}

static bool parseXml(const std::string& x, Node& root, std::string& err)
{
    root = Node{"#root"};
    std::vector<Node*> st{&root};
    size_t i = 0;
    const size_t n = x.size();

    while (i < n)
    {
        if (x[i] != '<')
        {
            size_t j = x.find('<', i);
            const size_t end = j == std::string::npos ? n : j;
            st.back()->text += unescape(x.substr(i, end - i));
            i = end;
            continue;
        }

        if (x.compare(i, 9, "<![CDATA[") == 0)
        {
            size_t j = x.find("]]>", i + 9);
            if (j == std::string::npos)
            {
                err = "Unclosed CDATA";
                return false;
            }
            st.back()->text += x.substr(i + 9, j - (i + 9));
            i = j + 3;
            continue;
        }

        if (x.compare(i, 4, "<!--") == 0)
        {
            size_t j = x.find("-->", i + 4);
            if (j == std::string::npos)
            {
                err = "Unclosed XML comment";
                return false;
            }
            i = j + 3;
            continue;
        }

        if (x.compare(i, 2, "<?") == 0)
        {
            size_t j = x.find("?>", i + 2);
            if (j == std::string::npos)
            {
                err = "Unclosed XML declaration";
                return false;
            }
            i = j + 2;
            continue;
        }

        size_t j = i + 1;
        bool closing = false;
        if (j < n && x[j] == '/')
        {
            closing = true;
            ++j;
        }
        while (j < n && std::isspace((unsigned char)x[j])) ++j;
        size_t ns = j;
        while (j < n && !std::isspace((unsigned char)x[j]) && x[j] != '>' && x[j] != '/') ++j;
        std::string name = x.substr(ns, j - ns);
        if (name.empty())
        {
            err = "Malformed XML tag";
            return false;
        }

        if (closing)
        {
            while (j < n && x[j] != '>') ++j;
            if (j >= n || st.size() < 2)
            {
                err = "Malformed closing tag";
                return false;
            }
            if (st.back()->name != name)
            {
                err = "Mismatched closing tag: " + name;
                return false;
            }
            st.pop_back();
            i = j + 1;
            continue;
        }

        Node node;
        node.name = std::move(name);
        bool self = false;

        while (j < n)
        {
            while (j < n && std::isspace((unsigned char)x[j])) ++j;
            if (j >= n)
            {
                err = "Unclosed tag";
                return false;
            }
            if (x[j] == '>')
            {
                ++j;
                break;
            }
            if (x[j] == '/')
            {
                self = true;
                ++j;
                while (j < n && std::isspace((unsigned char)x[j])) ++j;
                if (j >= n || x[j] != '>')
                {
                    err = "Malformed self-closing tag";
                    return false;
                }
                ++j;
                break;
            }

            size_t as = j;
            while (j < n && x[j] != '=' && !std::isspace((unsigned char)x[j]) && x[j] != '>') ++j;
            std::string ak = x.substr(as, j - as);
            while (j < n && std::isspace((unsigned char)x[j])) ++j;
            if (ak.empty() || j >= n || x[j] != '=')
            {
                err = "Malformed attribute";
                return false;
            }
            ++j;
            while (j < n && std::isspace((unsigned char)x[j])) ++j;
            if (j >= n || (x[j] != '\"' && x[j] != '\''))
            {
                err = "Malformed attribute quote";
                return false;
            }
            const char q = x[j++];
            const size_t av = j;
            while (j < n && x[j] != q) ++j;
            if (j >= n)
            {
                err = "Unclosed attribute";
                return false;
            }
            node.attrs[ak] = unescape(x.substr(av, j - av));
            ++j;
        }

        st.back()->children.push_back(std::move(node));
        Node* p = &st.back()->children.back();
        if (!self) st.push_back(p);
        i = j;
    }

    if (st.size() != 1)
    {
        err = "Unclosed XML element";
        return false;
    }
    return true;
}

static std::string nodeValue(const Node& n)
{
    if (n.children.empty()) return n.text;
    std::ostringstream o;
    bool first = true;
    for (const Node& c : n.children)
    {
        if (!first) o << ',';
        first = false;
        o << c.name << ':' << nodeValue(c);
    }
    return o.str();
}

static bool parseFloat(const std::string& s, float& out)
{
    try
    {
        size_t pos = 0;
        out = std::stof(s, &pos);
        return pos == s.size();
    }
    catch (...) { return false; }
}

static bool parseVec3(const Node& n, Vec3& v)
{
    bool hx = false, hy = false, hz = false;
    for (const Node& c : n.children)
    {
        float value = 0;
        if (!parseFloat(c.text, value)) continue;
        if (c.name == "X") { v.x = value; hx = true; }
        else if (c.name == "Y") { v.y = value; hy = true; }
        else if (c.name == "Z") { v.z = value; hz = true; }
    }
    return hx && hy && hz;
}

static std::string lower(std::string s)
{
    for (char& c : s) c = (char)std::tolower((unsigned char)c);
    return s;
}

static std::string serializeNode(const Node& n)
{
    std::ostringstream o;
    o << '<' << n.name;
    for (const auto& a : n.attrs)
        o << ' ' << a.first << "=\"" << esc(a.second) << '\"';
    if (n.children.empty() && n.text.empty())
    {
        o << "/>";
        return o.str();
    }
    o << '>';
    if (!n.text.empty()) o << esc(n.text);
    for (const Node& c : n.children) o << serializeNode(c);
    o << "</" << n.name << '>';
    return o.str();
}

static bool parseCoordinateFrame(const Node& n, std::array<float, 12>& m)
{
    bool have[12]{};
    const char* keys[] = {"X", "Y", "Z", "R00", "R01", "R02", "R10", "R11", "R12", "R20", "R21", "R22"};
    for (const Node& c : n.children)
    {
        float value = 0;
        if (!parseFloat(c.text, value)) continue;
        for (int i = 0; i < 12; ++i)
        {
            if (c.name == keys[i])
            {
                m[i] = value;
                have[i] = true;
                break;
            }
        }
    }
    for (int i = 0; i < 3; ++i) if (!have[i]) return false;
    return true;
}

static Vec3 matrixToEulerDegrees(const std::array<float, 12>& m)
{
    // XYZ Tait-Bryan extraction. This is intentionally only the editor-facing
    // representation; the exact imported matrix is retained in CFrameMatrix.
    const float r00=m[3], r01=m[4], r02=m[5];
    const float r10=m[6], r11=m[7], r12=m[8];
    const float r20=m[9], r21=m[10], r22=m[11];
    (void)r01; (void)r02; (void)r21; (void)r22;
    const float sy = clampf(-r20, -1.0f, 1.0f);
    const float y = std::asin(sy);
    float x = std::atan2(r21, r22);
    float z = std::atan2(r10, r00);
    const float cy = std::cos(y);
    if (std::abs(cy) < 1e-5f)
    {
        x = std::atan2(-r12, r11);
        z = 0.0f;
    }
    constexpr float radToDeg = 57.29577951308232f;
    return {x*radToDeg, y*radToDeg, z*radToDeg};
}

static bool split3(const std::string& s, float& x, float& y, float& z)
{
    char c1=0,c2=0;
    std::stringstream ss(s);
    if (!(ss >> x >> c1 >> y >> c2 >> z)) return false;
    return c1 == ',' && c2 == ',';
}

static std::string joinMatrix(const std::array<float, 12>& m)
{
    std::ostringstream o;
    o << std::setprecision(9);
    for (size_t i = 0; i < m.size(); ++i)
    {
        if (i) o << ',';
        o << m[i];
    }
    return o.str();
}

static bool parseMatrixString(const std::string& s, std::array<float,12>& m)
{
    std::stringstream ss(s);
    char comma = 0;
    for (size_t i=0;i<m.size();++i)
    {
        if (i && !(ss >> comma) || (i && comma != ',')) return false;
        if (!(ss >> m[i])) return false;
    }
    return true;
}

static std::string materialToken(const std::string& value)
{
    const std::string l = lower(value);
    if (l == "plastic") return "256";
    if (l == "smoothplastic") return "272";
    if (l == "neon") return "288";
    if (l == "wood") return "512";
    if (l == "slate") return "800";
    if (l == "concrete") return "816";
    if (l == "corrodedmetal") return "1040";
    if (l == "diamondplate") return "1056";
    if (l == "foil") return "1072";
    if (l == "grass") return "1280";
    if (l == "ice") return "1536";
    return value;
}

static std::string materialName(const std::string& token)
{
    if (token == "256") return "Plastic";
    if (token == "272") return "SmoothPlastic";
    if (token == "288") return "Neon";
    if (token == "512") return "Wood";
    if (token == "800") return "Slate";
    if (token == "816") return "Concrete";
    if (token == "1040") return "CorrodedMetal";
    if (token == "1056") return "DiamondPlate";
    if (token == "1072") return "Foil";
    if (token == "1280") return "Grass";
    if (token == "1536") return "Ice";
    return token;
}

static int colorByte(float v)
{
    return (int)std::lround(clampf(v,0.0f,1.0f)*255.0f);
}

static void readColor3(const Node& p, const std::shared_ptr<Instance>& inst)
{
    float r=0,g=0,b=0;
    bool hr=false,hg=false,hb=false;
    if (p.name == "Color3uint8" && p.children.empty())
    {
        try
        {
            unsigned long v = std::stoul(p.text, nullptr, 10);
            r = ((v >> 16) & 255) / 255.0f;
            g = ((v >> 8) & 255) / 255.0f;
            b = (v & 255) / 255.0f;
            inst->properties["Color"] = std::to_string(r)+","+std::to_string(g)+","+std::to_string(b);
            return;
        }
        catch (...) {}
    }
    for (const Node& c : p.children)
    {
        float v=0;
        if (!parseFloat(c.text,v)) continue;
        if (c.name=="R") {r=v;hr=true;}
        else if (c.name=="G") {g=v;hg=true;}
        else if (c.name=="B") {b=v;hb=true;}
    }
    if (hr&&hg&&hb)
    {
        // Color3uint8 can be found either as a packed integer or nested
        // channels. Values > 1 are interpreted as 8-bit channels.
        if (r>1.0f||g>1.0f||b>1.0f) { r/=255.0f; g/=255.0f; b/=255.0f; }
        inst->properties["Color"] = std::to_string(r)+","+std::to_string(g)+","+std::to_string(b);
    }
}

static void readProperties(const Node& props, const std::shared_ptr<Instance>& inst)
{
    for (const Node& p : props.children)
    {
        auto it = p.attrs.find("name");
        if (it == p.attrs.end()) continue;
        const std::string name = it->second;
        const std::string value = p.children.empty() ? p.text : nodeValue(p);
        inst->genericProperties.push_back({p.name, name, value, serializeNode(p), false});
        inst->properties[name] = value;

        const std::string ln = lower(name);
        if (ln == "source") inst->source = p.text;
        if (ln == "name") inst->name = p.text;

        if (p.name == "Vector3")
        {
            Vec3 v;
            if (parseVec3(p, v))
            {
                if (ln == "position" || ln == "pivotoffset")
                    inst->properties["Position"] = std::to_string(v.x)+","+std::to_string(v.y)+","+std::to_string(v.z);
                else if (ln == "size")
                    inst->properties["Size"] = std::to_string(v.x)+","+std::to_string(v.y)+","+std::to_string(v.z);
                else if (ln == "rotation" || ln == "orientation")
                    inst->properties["Rotation"] = std::to_string(v.x)+","+std::to_string(v.y)+","+std::to_string(v.z);
            }
        }

        if (p.name == "CoordinateFrame" && lower(inst->className) != "camera")
        {
            std::array<float,12> m{};
            if (parseCoordinateFrame(p, m))
            {
                inst->properties["Position"] = std::to_string(m[0])+","+std::to_string(m[1])+","+std::to_string(m[2]);
                Vec3 e = matrixToEulerDegrees(m);
                inst->properties["Rotation"] = std::to_string(e.x)+","+std::to_string(e.y)+","+std::to_string(e.z);
                inst->properties["CFrameMatrix"] = joinMatrix(m);
            }
        }

        if (p.name == "Color3" || p.name == "Color3uint8")
            readColor3(p, inst);

        if (p.name == "token" && ln == "material")
        {
            inst->properties["Material"] = materialName(p.text);
            inst->properties["MaterialToken"] = p.text;
        }
    }
}

static bool isKnownClass(const std::string& cls)
{
    static const char* known[] = {
        "DataModel","Workspace","Camera","Part","MeshPart","Model","Folder","SpawnLocation",
        "Script","LocalScript","ModuleScript","ScreenGui","Frame","TextLabel","TextButton",
        "ImageLabel","ImageButton","StarterGui","StarterPlayer","StarterPlayerScripts",
        "ReplicatedStorage","ServerScriptService","BoolValue","StringValue","IntValue","NumberValue"
    };
    for (const char* x : known) if (cls == x) return true;
    return false;
}

static void readItem(const Node& item, const std::shared_ptr<Instance>& parent, size_t& count, size_t& unknown)
{
    auto ci = item.attrs.find("class");
    if (ci == item.attrs.end()) return;
    const std::string cls = ci->second;
    auto inst = std::make_shared<Instance>(cls, cls);
    auto ri = item.attrs.find("referent");
    if (ri != item.attrs.end()) inst->referent = ri->second;
    inst->unknownClass = !isKnownClass(cls);
    if (inst->unknownClass) ++unknown;

    for (const Node& c : item.children)
        if (c.name == "Properties") readProperties(c, inst);

    if (inst->name.empty() || inst->name == cls) inst->name = cls;
    if (inst->referent.empty()) inst->referent = "RBX_IMPORTED_" + std::to_string(count+1);
    parent->addChild(inst);
    ++count;

    for (const Node& c : item.children)
        if (c.name == "Item") readItem(c, inst, count, unknown);
}

static void writeIndent(std::ostringstream& o, int n)
{
    for (int i=0;i<n;++i) o << "  ";
}

static void writeCoordinateFrame(std::ostringstream& o, int ind, const std::array<float,12>& m)
{
    writeIndent(o, ind);
    o << "<CoordinateFrame name=\"CFrame\">\n";
    const char* keys[] = {"X","Y","Z","R00","R01","R02","R10","R11","R12","R20","R21","R22"};
    for (int i=0;i<12;++i)
    {
        writeIndent(o, ind+1);
        o << '<' << keys[i] << '>' << std::setprecision(9) << m[i] << "</" << keys[i] << ">\n";
    }
    writeIndent(o, ind);
    o << "</CoordinateFrame>\n";
}

static std::array<float,12> matrixFromEuler(const std::string& pos, const std::string& rot)
{
    float px=0,py=0,pz=0, rx=0,ry=0,rz=0;
    split3(pos,px,py,pz);
    split3(rot,rx,ry,rz);
    constexpr float degToRad = 0.01745329251994329577f;
    rx*=degToRad; ry*=degToRad; rz*=degToRad;
    const float cx=std::cos(rx), sx=std::sin(rx), cy=std::cos(ry), sy=std::sin(ry), cz=std::cos(rz), sz=std::sin(rz);
    // Rz * Ry * Rx
    std::array<float,12> m{};
    m[0]=px; m[1]=py; m[2]=pz;
    m[3]=cz*cy;              m[4]=cz*sy*sx-sz*cx; m[5]=cz*sy*cx+sz*sx;
    m[6]=sz*cy;              m[7]=sz*sy*sx+cz*cx; m[8]=sz*sy*cx-cz*sx;
    m[9]=-sy;                m[10]=cy*sx;          m[11]=cy*cx;
    return m;
}

static void writeProperty(std::ostringstream& o, int ind, const std::string& name, const std::string& val, const std::string& cls, const std::shared_ptr<Instance>& inst)
{
    float x=0,y=0,z=0;
    if (name == "Position" && split3(val,x,y,z))
    {
        if (inst->isA("BasePart")) return; // emitted once as CFrame below
        writeIndent(o,ind);
        o << "<Vector3 name=\"position\"><X>" << x << "</X><Y>" << y << "</Y><Z>" << z << "</Z></Vector3>\n";
        return;
    }
    if (name == "Rotation" && split3(val,x,y,z))
    {
        if (inst->isA("BasePart")) return;
        writeIndent(o,ind);
        o << "<Vector3 name=\"rotation\"><X>" << x << "</X><Y>" << y << "</Y><Z>" << z << "</Z></Vector3>\n";
        return;
    }
    if (name == "Size" && split3(val,x,y,z))
    {
        writeIndent(o,ind);
        o << "<Vector3 name=\"size\"><X>" << x << "</X><Y>" << y << "</Y><Z>" << z << "</Z></Vector3>\n";
        return;
    }
    if (name == "Shape")
    {
        writeIndent(o,ind);
        o << "<string name=\"Shape\">" << esc(val) << "</string>\n";
        return;
    }
    if (name == "Color" && split3(val,x,y,z))
    {
        writeIndent(o,ind);
        o << "<Color3 name=\"Color\"><R>" << x << "</R><G>" << y << "</G><B>" << z << "</B></Color3>\n";
        return;
    }
    if (name == "Anchored" || name == "CanCollide" || name == "CanTouch" || name == "CanQuery")
    {
        writeIndent(o,ind);
        o << "<bool name=\"" << esc(name) << "\">" << (lower(val)=="true" ? "true" : "false") << "</bool>\n";
        return;
    }
    if (name == "Transparency" || name == "Reflectance")
    {
        writeIndent(o,ind);
        o << "<float name=\"" << esc(name) << "\">" << esc(val) << "</float>\n";
        return;
    }
    if (name == "Material")
    {
        writeIndent(o,ind);
        std::string token = materialToken(val);
        if (token != val || !token.empty())
            o << "<token name=\"Material\">" << esc(token) << "</token>\n";
        return;
    }
    writeIndent(o,ind);
    o << "<string name=\"" << esc(name) << "\">" << esc(val) << "</string>\n";
}

static void writeCdata(std::ostringstream& o, const std::string& source)
{
    size_t start = 0;
    while (true)
    {
        size_t p = source.find("]]>", start);
        if (p == std::string::npos) { o << source.substr(start); break; }
        o << source.substr(start, p-start) << "]]]]><![CDATA[>";
        start = p + 3;
    }
}

static void writeItem(std::ostringstream& o, const std::shared_ptr<Instance>& i, int ind)
{
    writeIndent(o,ind);
    o << "<Item class=\"" << esc(i->className) << "\" referent=\"" << esc(i->referent) << "\">\n";
    writeIndent(o,ind+1);
    o << "<Properties>\n";

    writeProperty(o,ind+2,"Name",i->name,i->className,i);

    if (i->isA("BasePart"))
    {
        std::array<float,12> matrix{};
        bool have = false;
        auto mi = i->properties.find("CFrameMatrix");
        if (mi != i->properties.end()) have = parseMatrixString(mi->second, matrix);
        if (!have)
        {
            auto p = i->properties.find("Position");
            auto r = i->properties.find("Rotation");
            matrix = matrixFromEuler(p == i->properties.end() ? "0,0,0" : p->second, r == i->properties.end() ? "0,0,0" : r->second);
        }
        writeCoordinateFrame(o,ind+2,matrix);
    }

    const std::vector<std::string> keys = {"Shape","Size","Color","Material","Transparency","Reflectance","Anchored","CanCollide","CanTouch","CanQuery"};
    for (const auto& k : keys)
    {
        auto it = i->properties.find(k);
        if (it != i->properties.end()) writeProperty(o,ind+2,k,it->second,i->className,i);
    }
    if (!i->source.empty())
    {
        writeIndent(o,ind+2);
        o << "<ProtectedString name=\"Source\"><![CDATA["; writeCdata(o, i->source); o << "]]></ProtectedString>\n";
    }

    for (const auto& gp : i->genericProperties)
    {
        if (gp.dirty) continue;
        if (gp.name == "Name" || gp.name == "Source" || gp.name == "Position" || gp.name == "Rotation" ||
            gp.name == "Shape" || gp.name == "Size" || gp.name == "Color" || gp.name == "Material" || gp.name == "Transparency" ||
            gp.name == "Reflectance" || gp.name == "Anchored" || gp.name == "CanCollide" || gp.name == "CanTouch" ||
            gp.name == "CanQuery" || (i->isA("BasePart") && gp.name == "CFrame")) continue;
        writeIndent(o,ind+2);
        if (!gp.rawXml.empty()) o << gp.rawXml;
        else o << '<' << gp.tag << " name=\"" << esc(gp.name) << "\">" << esc(gp.rawValue) << "</" << gp.tag << '>';
        o << '\n';
    }

    writeIndent(o,ind+1);
    o << "</Properties>\n";
    for (const auto& c : i->children) writeItem(o,c,ind+1);
    writeIndent(o,ind);
    o << "</Item>\n";
}

} // namespace

RbxlxResult RbxlxCodec::importXml(const std::string& xml, DataModel& model)
{
    RbxlxResult r;
    Node doc;
    if (!parseXml(xml,doc,r.error)) return r;

    model.resetEmpty();
    auto root = model.root();
    std::function<void(const Node&,const std::shared_ptr<Instance>&)> walk = [&](const Node& n,const std::shared_ptr<Instance>& parent)
    {
        for (const Node& c : n.children)
        {
            if (c.name == "Item") readItem(c,parent,r.instances,r.unknown);
            else walk(c,parent);
        }
    };
    walk(doc,root);
    r.ok = true;
    return r;
}

std::string RbxlxCodec::exportXml(const DataModel& model)
{
    std::ostringstream o;
    o << "<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\"?>\n";
    o << "<roblox version=\"4\" xmlns:xmime=\"http://www.w3.org/2005/05/xmlmime\">\n";
    writeIndent(o,1);
    o << "<Meta name=\"PluginDebugService\" version=\"0\"/>\n";
    for (const auto& c : model.root()->children) writeItem(o,c,1);
    o << "</roblox>\n";
    return o.str();
}

} // namespace Studio
