#pragma once
#include "Math.h"
#include <string>
#include <vector>
#include <unordered_map>
#include <memory>
#include <mutex>

namespace Studio {

struct GenericProperty {
    std::string tag;
    std::string name;
    std::string rawValue;
    std::string rawXml;
    bool dirty = false;
};

class Instance : public std::enable_shared_from_this<Instance> {
public:
    std::string className;
    std::string name;
    std::string referent;
    std::string source;
    bool unknownClass = false;
    std::weak_ptr<Instance> parent;
    std::vector<std::shared_ptr<Instance>> children;
    std::unordered_map<std::string,std::string> properties;
    std::unordered_map<std::string,std::string> attributes;
    std::vector<std::string> tags;
    std::vector<GenericProperty> genericProperties;

    explicit Instance(std::string cls, std::string n="") : className(std::move(cls)), name(std::move(n)) {}

    std::shared_ptr<Instance> addChild(const std::shared_ptr<Instance>& child);
    bool removeChild(const std::shared_ptr<Instance>& child);
    std::shared_ptr<Instance> findByName(const std::string& n);
    std::shared_ptr<Instance> findByReferent(const std::string& r);
    size_t descendantCount() const;
    bool isA(const std::string& cls) const;
};

class DataModel {
public:
    DataModel();
    void reset();
    void resetEmpty();
    std::shared_ptr<Instance> root() const { return root_; }
    std::shared_ptr<Instance> getOrCreateService(const std::string& cls);
    std::shared_ptr<Instance> findPath(const std::string& path) const;
    std::shared_ptr<Instance> findById(const std::string& ref) const;
    bool setProperty(const std::string& ref, const std::string& key, const std::string& value);
    std::string getPropertiesJson(const std::string& ref) const;
    std::string getSource(const std::string& ref) const;
    bool setSource(const std::string& ref, const std::string& source);
    std::vector<std::shared_ptr<Instance>> scriptSnapshot() const;
    std::shared_ptr<Instance> addPart(const std::string& shape);
    std::shared_ptr<Instance> addObject(const std::string& cls, const std::string& parentId="");
    std::shared_ptr<Instance> duplicate(const std::shared_ptr<Instance>& src);
    bool deleteInstance(const std::shared_ptr<Instance>& obj);
    std::shared_ptr<Instance> moveInstance(const std::shared_ptr<Instance>& obj, const std::shared_ptr<Instance>& newParent);
    size_t objectCount() const;
    std::string sceneJson() const;
    std::string hierarchyJson() const;
private:
    std::shared_ptr<Instance> root_;
    mutable std::mutex mutex_;
    uint64_t nextId_=1;
    std::string makeReferent();
    void seedDefaultProject();
    std::shared_ptr<Instance> cloneTree(const std::shared_ptr<Instance>& src);
};

}
