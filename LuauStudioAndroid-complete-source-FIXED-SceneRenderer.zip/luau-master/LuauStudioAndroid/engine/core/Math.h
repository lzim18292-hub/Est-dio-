#pragma once
#include <cmath>
#include <algorithm>

namespace Studio {
struct Vec3 { float x=0, y=0, z=0; };
struct Color3 { float r=0.7f, g=0.7f, b=0.7f; };
struct Mat4 {
    float m[16]{};
    static Mat4 identity();
};
inline Vec3 operator+(Vec3 a, Vec3 b){ return {a.x+b.x,a.y+b.y,a.z+b.z}; }
inline Vec3 operator-(Vec3 a, Vec3 b){ return {a.x-b.x,a.y-b.y,a.z-b.z}; }
inline Vec3 operator*(Vec3 a,float s){ return {a.x*s,a.y*s,a.z*s}; }
inline float dot(Vec3 a, Vec3 b){ return a.x*b.x+a.y*b.y+a.z*b.z; }
inline float length(Vec3 a){ return std::sqrt(dot(a,a)); }
inline Vec3 normalize(Vec3 a){ float l=length(a); return l>1e-6f?a*(1.0f/l):Vec3{}; }
inline float clampf(float v,float lo,float hi){return std::max(lo,std::min(hi,v));}
}
