#include "Instance.h"
#include <sstream>
#include <iomanip>
#include <cctype>
#include <functional>
#include <cmath>

namespace Studio {

std::shared_ptr<Instance> Instance::addChild(const std::shared_ptr<Instance>& child){
    if(!child) return nullptr;
    if(auto p=child->parent.lock()){ p->removeChild(child); }
    child->parent=shared_from_this();
    children.push_back(child);
    return child;
}
bool Instance::removeChild(const std::shared_ptr<Instance>& child){
    auto it=std::find(children.begin(),children.end(),child);
    if(it==children.end()) return false;
    (*it)->parent.reset(); children.erase(it); return true;
}
std::shared_ptr<Instance> Instance::findByName(const std::string& n){
    for(auto& c:children){ if(c->name==n) return c; if(auto x=c->findByName(n)) return x; }
    return nullptr;
}
std::shared_ptr<Instance> Instance::findByReferent(const std::string& r){
    if(referent==r) return shared_from_this();
    for(auto& c:children){ if(auto x=c->findByReferent(r)) return x; }
    return nullptr;
}
size_t Instance::descendantCount() const { size_t n=children.size(); for(auto& c:children)n+=c->descendantCount(); return n; }
bool Instance::isA(const std::string& cls) const { return className==cls || (cls=="BasePart" && (className=="Part"||className=="MeshPart"||className=="SpawnLocation")); }

static std::string jsonEscape(const std::string& s){
    std::string o; o.reserve(s.size()+8);
    for(char c:s){ switch(c){case '\\':o+="\\\\";break;case '"':o+="\\\"";break;case '\n':o+="\\n";break;case '\r':o+="\\r";break;case '\t':o+="\\t";break;default:o+=c;} } return o;
}
static std::string prop(const std::shared_ptr<Instance>& i,const char* k,const char* d=""){
    auto it=i->properties.find(k); return it==i->properties.end()?d:it->second;
}

DataModel::DataModel(){ reset(); }
void DataModel::reset(){ std::lock_guard<std::mutex> l(mutex_); root_=std::make_shared<Instance>("DataModel","game"); nextId_=1; seedDefaultProject(); }
void DataModel::resetEmpty(){ std::lock_guard<std::mutex> l(mutex_); root_=std::make_shared<Instance>("DataModel","game"); nextId_=1; }
std::string DataModel::makeReferent(){ std::ostringstream s; s<<"RBXSTUDIO_"<<std::hex<<nextId_++; return s.str(); }
std::shared_ptr<Instance> DataModel::getOrCreateService(const std::string& cls){
    for(auto& c:root_->children) if(c->className==cls && c->name==cls) return c;
    auto s=std::make_shared<Instance>(cls,cls); s->referent=makeReferent(); root_->addChild(s); return s;
}
void DataModel::seedDefaultProject(){
    auto ws=getOrCreateService("Workspace");
    ws->properties["Gravity"]="196.2";
    auto cam=std::make_shared<Instance>("Camera","Camera"); cam->referent=makeReferent(); cam->properties["Position"]="0,8,18"; cam->properties["Fov"]="70"; ws->addChild(cam);
    auto base=std::make_shared<Instance>("Part","Baseplate"); base->referent=makeReferent();
    base->properties["Shape"]="Block"; base->properties["Position"]="0,-0.5,0"; base->properties["Size"]="48,1,48"; base->properties["Color"]="0.25,0.28,0.32"; base->properties["Material"]="Concrete"; base->properties["Anchored"]="true"; ws->addChild(base);
    auto spawn=std::make_shared<Instance>("SpawnLocation","SpawnLocation"); spawn->referent=makeReferent(); spawn->properties["Position"]="0,0.6,0"; spawn->properties["Size"]="6,1,6"; spawn->properties["Color"]="0.15,0.55,1"; spawn->properties["Anchored"]="true"; ws->addChild(spawn);
    getOrCreateService("ReplicatedStorage"); getOrCreateService("ServerScriptService"); getOrCreateService("StarterGui"); getOrCreateService("StarterPlayer");
}
std::shared_ptr<Instance> DataModel::findPath(const std::string& path) const{
    if(path=="game"||path==".") return root_;
    std::shared_ptr<Instance> cur=root_; size_t start=0; while(start<path.size() && path[start]=='/') start++;
    std::stringstream ss(path.substr(start)); std::string p; std::vector<std::string> parts; while(std::getline(ss,p,'.')) if(!p.empty() && p!="game") parts.push_back(p);
    for(auto& name:parts){ auto n=std::find_if(cur->children.begin(),cur->children.end(),[&](auto& x){return x->name==name;}); if(n==cur->children.end()) return nullptr; cur=*n; } return cur;
}
std::shared_ptr<Instance> DataModel::findById(const std::string& ref) const {
    std::lock_guard<std::mutex> l(mutex_);
    return root_->findByReferent(ref);
}
static std::string jsonEscapeProp(const std::string& s){
    std::string o; o.reserve(s.size()+8);
    for(char c:s){switch(c){case '\\':o+="\\\\";break;case '"':o+="\\\"";break;case '\n':o+="\\n";break;case '\r':o+="\\r";break;case '\t':o+="\\t";break;default:o+=c;}}
    return o;
}
bool DataModel::setProperty(const std::string& ref,const std::string& key,const std::string& value){
    std::lock_guard<std::mutex> l(mutex_); auto p=root_->findByReferent(ref); if(!p) return false;
    p->properties[key]=value;
    if(key=="Name") p->name=value;
    if(key=="Source") p->source=value;
    if(key=="Position"||key=="Rotation") p->properties.erase("CFrameMatrix");
    if(key=="Material") p->properties.erase("MaterialToken");
    return true;
}
std::string DataModel::getPropertiesJson(const std::string& ref) const{
    std::lock_guard<std::mutex> l(mutex_); auto p=root_->findByReferent(ref); if(!p) return "{}";
    std::ostringstream o; o<<"{\"name\":\""<<jsonEscapeProp(p->name)<<"\",\"class\":\""<<jsonEscapeProp(p->className)<<"\",\"source\":\""<<jsonEscapeProp(p->source)<<"\",\"properties\":{";
    bool first=true; for(auto& kv:p->properties){if(!first)o<<',';first=false;o<<"\""<<jsonEscapeProp(kv.first)<<"\":\""<<jsonEscapeProp(kv.second)<<"\"";} o<<"}}"; return o.str();
}
std::string DataModel::getSource(const std::string& ref) const{
    std::lock_guard<std::mutex> l(mutex_); auto p=root_->findByReferent(ref); return p?p->source:"";
}
bool DataModel::setSource(const std::string& ref,const std::string& source){
    std::lock_guard<std::mutex> l(mutex_); auto p=root_->findByReferent(ref); if(!p) return false; p->source=source; p->properties["Source"]=source; return true;
}
std::vector<std::shared_ptr<Instance>> DataModel::scriptSnapshot() const{
    std::lock_guard<std::mutex> l(mutex_); std::vector<std::shared_ptr<Instance>> out;
    std::function<void(const std::shared_ptr<Instance>&)> rec=[&](const std::shared_ptr<Instance>& i){if(i->className=="Script"||i->className=="LocalScript"||i->className=="ModuleScript") out.push_back(i);for(auto& c:i->children) rec(c);};
    rec(root_); return out;
}
std::shared_ptr<Instance> DataModel::addObject(const std::string& cls, const std::string& parentId){
    std::lock_guard<std::mutex> l(mutex_);
    std::shared_ptr<Instance> parent;
    if(!parentId.empty()) parent=root_->findByReferent(parentId);
    if(!parent) {
        if(cls=="Script"||cls=="LocalScript"||cls=="ModuleScript") parent=getOrCreateService("ServerScriptService");
        else if(cls=="ScreenGui") parent=getOrCreateService("StarterGui");
        else if(cls=="Folder"||cls=="Model") parent=getOrCreateService("Workspace");
        else parent=root_;
    }
    int n=0; for(auto& c:parent->children) if(c->className==cls)n++;
    std::string base=cls;
    auto obj=std::make_shared<Instance>(cls,base+(n?std::to_string(n+1):"")); obj->referent=makeReferent();
    if(cls=="Script"||cls=="LocalScript"||cls=="ModuleScript") obj->source="-- Luau Studio script\nprint(\"Hello from Luau Studio\")";
    parent->addChild(obj); return obj;
}
std::shared_ptr<Instance> DataModel::addPart(const std::string& shape){
    std::lock_guard<std::mutex> l(mutex_); auto ws=getOrCreateService("Workspace");
    int count=0; for(auto& c:ws->children) if(c->isA("BasePart")) count++;
    auto p=std::make_shared<Instance>("Part","Part"); p->referent=makeReferent(); p->properties["Shape"]=shape; p->properties["Position"]="0,2,"+std::to_string(count*4); p->properties["Size"]="4,4,4"; p->properties["Color"]="0.35,0.65,1"; p->properties["Material"]="Plastic"; p->properties["Anchored"]="true"; p->properties["CanCollide"]="true"; p->properties["Transparency"]="0"; p->properties["Reflectance"]="0"; p->properties["CanTouch"]="true"; p->properties["CanQuery"]="true"; ws->addChild(p); return p;
}
std::shared_ptr<Instance> DataModel::cloneTree(const std::shared_ptr<Instance>& src){
    auto x=std::make_shared<Instance>(src->className,src->name+" Copy"); x->referent=makeReferent(); x->source=src->source; x->unknownClass=src->unknownClass; x->properties=src->properties; x->attributes=src->attributes; x->tags=src->tags; x->genericProperties=src->genericProperties; for(auto& c:src->children) x->addChild(cloneTree(c)); return x;
}
std::shared_ptr<Instance> DataModel::duplicate(const std::shared_ptr<Instance>& src){ std::lock_guard<std::mutex> l(mutex_); if(!src||src==root_) return nullptr; auto p=src->parent.lock(); if(!p) return nullptr; return p->addChild(cloneTree(src)); }
bool DataModel::deleteInstance(const std::shared_ptr<Instance>& obj){ std::lock_guard<std::mutex> l(mutex_); if(!obj||obj==root_)return false; if(auto p=obj->parent.lock())return p->removeChild(obj); return false; }
std::shared_ptr<Instance> DataModel::moveInstance(const std::shared_ptr<Instance>& obj,const std::shared_ptr<Instance>& newParent){ std::lock_guard<std::mutex> l(mutex_); if(!obj||!newParent||obj==root_||obj==newParent)return nullptr; for(auto a=newParent;a;a=a->parent.lock()) if(a==obj)return nullptr; newParent->addChild(obj); return obj; }
size_t DataModel::objectCount() const { std::lock_guard<std::mutex> l(mutex_); return root_->descendantCount(); }
std::string DataModel::sceneJson() const{
    std::lock_guard<std::mutex> l(mutex_); std::ostringstream o; o<<"["; bool first=true;
    std::function<void(const std::shared_ptr<Instance>&)> rec=[&](const std::shared_ptr<Instance>& i){
        if(i->isA("BasePart")){
            if(!first)o<<','; first=false; o<<"{\"id\":\""<<jsonEscape(i->referent)<<"\",\"name\":\""<<jsonEscape(i->name)<<"\",\"class\":\""<<jsonEscape(i->className)<<"\",\"shape\":\""<<jsonEscape(prop(i,"Shape","Block"))<<"\",\"pos\":\""<<jsonEscape(prop(i,"Position","0,0,0"))<<"\",\"size\":\""<<jsonEscape(prop(i,"Size","4,4,4"))<<"\",\"color\":\""<<jsonEscape(prop(i,"Color","0.6,0.6,0.6"))<<"\",\"rot\":\""<<jsonEscape(prop(i,"Rotation","0,0,0"))<<"\"}";
        }
        for(auto& c:i->children) rec(c);
    }; rec(root_); o<<"]"; return o.str();
}
std::string DataModel::hierarchyJson() const{
    std::lock_guard<std::mutex> l(mutex_); std::ostringstream o;
    std::function<void(const std::shared_ptr<Instance>&)> rec=[&](const std::shared_ptr<Instance>& i){
        o<<"{\"id\":\""<<jsonEscape(i->referent)<<"\",\"name\":\""<<jsonEscape(i->name)<<"\",\"class\":\""<<jsonEscape(i->className)<<"\",\"children\":["; for(size_t k=0;k<i->children.size();++k){ if(k)o<<','; rec(i->children[k]); } o<<"]}";
    }; rec(root_); return o.str();
}
}
