#include <fstream>
#include <iostream>
#include <sstream>
#include "../engine/core/Instance.h"
#include "../engine/serialization/Rbxlx.h"
static std::string readAll(const char* p){std::ifstream f(p,std::ios::binary);std::ostringstream o;o<<f.rdbuf();return o.str();}
int main(int argc,char**argv){
    if(argc<2){std::cerr<<"fixture required\n";return 2;}
    const std::string xml=readAll(argv[1]); if(xml.empty()){std::cerr<<"fixture empty\n";return 3;}
    Studio::DataModel m; auto r=Studio::RbxlxCodec::importXml(xml,m);
    if(!r.ok){std::cerr<<"import failed: "<<r.error<<"\n";return 4;}
    if(m.objectCount()<130 || r.unknown<1){std::cerr<<"unexpected counts objects="<<m.objectCount()<<" unknown="<<r.unknown<<"\n";return 5;}
    const std::string out=Studio::RbxlxCodec::exportXml(m);
    if(out.find("UnknownPreserved")==std::string::npos || out.find("Service30")==std::string::npos) return 6;
    std::cout<<"LARGE PROJECT OK objects="<<m.objectCount()<<" imported="<<r.instances<<" unknown="<<r.unknown<<" output_bytes="<<out.size()<<"\n";
    return 0;
}
