#include <iostream>
#include "../engine/core/Instance.h"
#include "../engine/serialization/Rbxlx.h"
#include "../engine/runtime/LuauRuntime.h"
int main(){ Studio::DataModel m; auto p=m.addPart("Sphere"); p->properties["Position"]="1,2,3"; p->source=""; auto xml=Studio::RbxlxCodec::exportXml(m); Studio::DataModel m2; auto r=Studio::RbxlxCodec::importXml(xml,m2); if(!r.ok||m2.objectCount()==0){std::cerr<<"RBXLX failed: "<<r.error<<"\n";return 2;} auto s=m2.addObject("Script");s->source="print('smoke ok')";Studio::LuauRuntime rt;auto out=rt.run(m2);for(auto&x:out)std::cout<<x.level<<":"<<x.message<<"\n";return 0;}
