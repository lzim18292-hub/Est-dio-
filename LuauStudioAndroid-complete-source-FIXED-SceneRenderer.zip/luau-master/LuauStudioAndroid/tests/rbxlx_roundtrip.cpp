#include <iostream>
#include <string>
#include <cmath>
#include "../engine/core/Instance.h"
#include "../engine/serialization/Rbxlx.h"

static bool has(const std::string& x,const std::string& y){return x.find(y)!=std::string::npos;}

int main(){
    const std::string xml=R"XML(<?xml version="1.0"?><roblox version="4">
<Item class="Workspace" referent="W"><Properties>
<string name="Name">Workspace</string>
<BinaryString name="AttributesSerialize">QUJDRA==</BinaryString>
</Properties>
<Item class="Part" referent="P"><Properties>
<string name="Name">RotatedPart</string>
<CoordinateFrame name="CFrame"><X>1</X><Y>2</Y><Z>3</Z><R00>0</R00><R01>-1</R01><R02>0</R02><R10>1</R10><R11>0</R11><R12>0</R12><R20>0</R20><R21>0</R21><R22>1</R22></CoordinateFrame>
<Vector3 name="size"><X>4</X><Y>5</Y><Z>6</Z></Vector3>
<Color3uint8 name="Color3uint8">3368550</Color3uint8>
<token name="Material">288</token>
<bool name="Anchored">true</bool>
<ProtectedString name="Source"><![CDATA[print("part source")]]></ProtectedString>
</Properties></Item>
<Item class="UnknownFutureClass" referent="X"><Properties>
<string name="Name">FutureThing</string>
<Vector3 name="Mystery"><X>1</X><Y>2</Y><Z>3</Z></Vector3>
<ProtectedString name="Source"><![CDATA[print("CDATA works")]]></ProtectedString>
</Properties></Item>
<Item class="Script" referent="S"><Properties><string name="Name">ServerScript</string><ProtectedString name="Source"><![CDATA[print("hello")]]></ProtectedString></Properties></Item>
</Item></roblox>)XML";

    Studio::DataModel m;
    auto r=Studio::RbxlxCodec::importXml(xml,m);
    if(!r.ok){std::cerr<<"import: "<<r.error;return 2;}
    if(r.instances!=4 || r.unknown!=1)return 3;
    auto x=m.root()->findByReferent("X"); if(!x||!x->unknownClass||x->source!="print(\"CDATA works\")")return 4;
    auto p=m.root()->findByReferent("P"); if(!p)return 5;
    if(p->properties["Material"]!="Neon") return 6;
    if(p->properties["Position"]!="1.000000,2.000000,3.000000") return 7;
    if(p->properties.find("CFrameMatrix")==p->properties.end()) return 8;

    std::string out=Studio::RbxlxCodec::exportXml(m);
    if(!has(out,"UnknownFutureClass")||!has(out,"AttributesSerialize")||!has(out,"CDATA works"))return 9;
    if(!has(out,"<CoordinateFrame name=\"CFrame\">")||!has(out,"<token name=\"Material\">288</token>"))return 10;
    if(!has(out,"<ProtectedString name=\"Source\"><![CDATA[print(&quot;part source&quot;)]]>")){
        // Source CDATA is deliberately allowed to contain quotes without XML escaping;
        // current serializer preserves source literally, so check for a valid Source tag instead.
        if(!has(out,"<ProtectedString name=\"Source\"><![CDATA[print(\"part source\")]]>")) return 11;
    }
    std::cout<<"RBXLX roundtrip OK instances="<<r.instances<<" unknown="<<r.unknown<<" bytes="<<out.size()<<"\n";
    return 0;
}
