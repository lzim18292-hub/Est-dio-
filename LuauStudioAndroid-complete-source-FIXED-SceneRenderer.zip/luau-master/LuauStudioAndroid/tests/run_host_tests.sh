#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
BUILD="$ROOT/build-host"
mkdir -p /tmp/luau-studio-tests
cmake --build "$BUILD" --target Luau.Compiler Luau.VM Luau.Config -j2
COMMON=( -std=c++17 -I"$ROOT/VM/include" -I"$ROOT/Compiler/include" -I"$ROOT/Ast/include" -I"$ROOT/Bytecode/include" -I"$ROOT/Common/include" -I"$ROOT/Config/include" -I"$ROOT/LuauStudioAndroid/engine/core" -I"$ROOT/LuauStudioAndroid/engine/serialization" -I"$ROOT/LuauStudioAndroid/engine/runtime" )
g++ "${COMMON[@]}" "$ROOT/LuauStudioAndroid/tests/host_smoke.cpp" "$ROOT/LuauStudioAndroid/engine/core/Instance.cpp" "$ROOT/LuauStudioAndroid/engine/serialization/Rbxlx.cpp" "$ROOT/LuauStudioAndroid/engine/runtime/LuauRuntime.cpp" "$BUILD/libLuau.Compiler.a" "$BUILD/libLuau.VM.a" "$BUILD/libLuau.Config.a" "$BUILD/libLuau.Ast.a" "$BUILD/libLuau.Bytecode.a" "$BUILD/libLuau.Common.a" -ldl -lm -pthread -o /tmp/luau-studio-tests/host_smoke
/tmp/luau-studio-tests/host_smoke
g++ -std=c++17 -I"$ROOT/LuauStudioAndroid/engine/core" -I"$ROOT/LuauStudioAndroid/engine/serialization" "$ROOT/LuauStudioAndroid/tests/rbxlx_roundtrip.cpp" "$ROOT/LuauStudioAndroid/engine/core/Instance.cpp" "$ROOT/LuauStudioAndroid/engine/serialization/Rbxlx.cpp" -o /tmp/luau-studio-tests/rbxlx_roundtrip
/tmp/luau-studio-tests/rbxlx_roundtrip
g++ -std=c++17 -I"$ROOT/LuauStudioAndroid/engine/core" -I"$ROOT/LuauStudioAndroid/engine/serialization" "$ROOT/LuauStudioAndroid/tests/large_project_stress.cpp" "$ROOT/LuauStudioAndroid/engine/core/Instance.cpp" "$ROOT/LuauStudioAndroid/engine/serialization/Rbxlx.cpp" -o /tmp/luau-studio-tests/large_project_stress
/tmp/luau-studio-tests/large_project_stress "$ROOT/LuauStudioAndroid/tests/fixtures/large_project.rbxlx"
echo "ALL HOST TESTS PASSED"
