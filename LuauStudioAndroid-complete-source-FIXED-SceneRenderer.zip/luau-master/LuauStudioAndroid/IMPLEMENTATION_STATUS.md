# Implementation status

## Implemented in source

- Official Luau VM/compiler embedded through CMake.
- Native Android project for ARM64 (`arm64-v8a`).
- OpenGL ES 3.0 3D viewport with generated primitive meshes.
- Touch orbit/pan-like object manipulation and pinch zoom.
- SELECT / MOVE / ROTATE / SCALE tools.
- Block, Sphere, Cylinder, Wedge and CornerWedge creation/rendering.
- Workspace plus core service containers.
- Explorer with collapse/expand, selection and case-insensitive search.
- Properties editing for Name, Position, Rotation, Size, Color, Material, Transparency, Reflectance, Anchored, CanCollide, CanTouch and CanQuery.
- Duplicate, delete and reparent/move between valid containers.
- Toolbox panel for built-in primitives and object classes.
- Script, LocalScript and ModuleScript storage.
- Mobile Luau editor with line numbers, lightweight keyword/string highlighting, find, replace-all, copy/paste through the Android text editor and symbol insertion buttons.
- Embedded Luau runtime using the official VM/compiler, with safe standard libraries, print/warn Output and syntax/runtime reporting.
- PLAY worker-thread execution and STOP requests honored between scripts.
- RBXLX XML import/export.
- CoordinateFrame preservation for BaseParts; edited transforms regenerate CFrame.
- Color3/Color3uint8 decoding and Material token/name normalization for common materials.
- Shape preservation for editor-created Parts.
- Unknown Instance classes retained with children and generic properties.
- Unknown property XML retained and emitted on export.
- ProtectedString/CDATA handling, referents and raw serialized Attribute/Tag properties retained for round-trip.
- Android Storage Access Framework import/export.
- Local app-private `project.rbxlx` save.
- LOW-END / BALANCED / HIGH render object caps.
- 128 MB mobile-safe XML import guard.

## Host validation executed

1. Official Luau `Compiler` and `VM` libraries compiled with CMake/Ninja.
2. `host_smoke`: create Part -> export RBXLX -> import RBXLX -> run Luau -> Output. **PASS**.
3. `rbxlx_roundtrip`: CFrame + Color3uint8 + Material token + unknown class + generic XML + CDATA. **PASS**.
4. `large_project_stress`: 100 Parts + 30 Scripts + Services + GUI + unknown class. **PASS** (`139` objects, `1` unknown class, exported successfully).
5. Native JNI bridge syntax check against a minimal JNI header. **PASS**.

## Not validated in this workspace

- Final APK compilation/install: Android SDK, Build-Tools, NDK and Gradle are not installed in this execution environment.
- Physical Android performance/RAM/FPS test on a 4 GB ARM64 phone.
- Full binary `.rbxl` decoding/export. An isolated `RbxlBinaryCodec` interface is included so this can be added without changing the editor/DataModel contract.
- Full Roblox physics/replication and exact Roblox API/runtime parity.
- Full semantic decoding/editing of Attribute/Tag binary serialization; raw serialized XML nodes are preserved.
- MeshPart geometry loading, texture/Decal sampling and audio playback. MeshPart/Decal/Sound instances are retained as DataModel metadata instead of being silently discarded.
- A production-grade virtualized Explorer for extremely large trees; the current Explorer is functional but should be replaced with a recycler/virtual list before targeting tens of thousands of nodes.
- Native undo/redo history across the whole DataModel.

These are explicit limitations; the project does not represent them as completed functionality.
