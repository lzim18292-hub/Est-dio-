# Luau Studio Android — Delivery Report

## Base

Source: official `luau-lang/luau` repository supplied by the user.
The original Luau source tree is retained. All new editor code lives under `LuauStudioAndroid/`.

## What is working and validated

The C++ core was compiled against the official Luau Compiler/VM libraries on the host. The following tests passed:

- Host smoke: Part -> RBXLX export -> RBXLX import -> Luau execution -> Output.
- RBXLX round-trip: CoordinateFrame, Color3uint8, Material token, Shape, unknown class, generic property and ProtectedString/CDATA handling.
- Large-project stress: 100 Parts + 30 Scripts + services + GUI + an unknown class; 139 objects were imported and re-exported without dropping the unknown class.
- JNI bridge syntax check passed against a minimal JNI ABI stub.

The Android project contains the functional editor-side implementation for the requested main flow, but it has not been packaged into an APK in this build environment.

## Android build blocker in this environment

This execution environment has CMake/Ninja and a native C++ compiler, but no Android SDK, Android Build-Tools, Android NDK, Gradle installation, or ADB. There is also no usable network/DNS path here to install the missing Android toolchain. Therefore an APK cannot be truthfully claimed as built here.

The project includes a GitHub Actions workflow that provisions the missing Android toolchain on a GitHub-hosted runner and uploads `app-debug.apk`.

## Requested success criteria

1. Install APK on Android — **source/build automation ready; APK not built here**.
2. Open editor — **implemented in source**.
3. 3D world — **implemented**.
4. Create Part — **implemented**.
5. Move/rotate/scale — **implemented by touch + properties**.
6. Explorer — **implemented with hierarchy, collapse/expand, search and selection**.
7. Properties — **implemented for core Part properties**.
8. Luau script create/edit — **implemented**.
9. Play/test — **implemented for safe Script/LocalScript subset**.
10. Save — **implemented as local RBXLX save**.
11. Import RBXLX — **implemented**.
12. View imported hierarchy — **implemented**.
13. Edit imported project — **core transforms/properties/scripts are editable**.
14. Export RBXLX — **implemented**.

## Known limitations

- `.rbxl` binary format is isolated behind `RbxlBinaryCodec` but not implemented.
- The runtime is deliberately a safe Luau subset; full Roblox API/physics/replication is not present.
- ModuleScripts are preserved but not yet integrated with a full Instance userdata/require system.
- Attributes/Tags binary payloads are preserved as raw serialized XML properties but are not semantically decoded/edited.
- MeshPart/Decal/Sound instances are preserved as metadata; native geometry/texture/audio asset decoding is not complete.
- Extremely large Explorer trees need a virtualized list before targeting tens of thousands of nodes.
- No physical 4 GB Android device performance measurement was possible here.
- Final APK size and RAM use are intentionally **not invented**; they must be measured after a real Android build and device run.
