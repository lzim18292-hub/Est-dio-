# UI/UX Part 2 — Post-Creation Audit

## Status

Part 2 is a broad functional expansion, not the final 100% application state.

## Verified in the working tree

- `MainActivity.java` brace/syntax structure checked by static balance validation: PASS.
- `SceneRenderer.java` brace/syntax structure checked by static balance validation: PASS.
- `Instance.cpp` compiles with `g++ -std=c++17`: PASS.
- `Rbxlx.cpp` compiles with `g++ -std=c++17`: PASS.
- RBXLX roundtrip host test: PASS (`instances=4`, `unknown=1`).
- Large project stress test: PASS (`objects=139`, `imported=139`, `unknown=1`).

## What is complete in this pass

- Broad editor UX expansion instead of isolated one-button changes.
- Undo/Redo user flow and state restoration.
- Viewport navigation controls and scene presentation improvements.
- Material/transparency metadata reaching the renderer.
- Explorer object context actions.
- Output filtering and script navigation surface.
- Script typing persistence and editor toolbar.
- Android image-asset selection and metadata linking flow.

## Still incomplete / must remain on the backlog

### High priority

1. True GPU texture decoding, UV coordinates, texture upload, cache and visible texture sampling. `TextureUri` is currently linked as metadata; imported images are NOT yet rendered onto geometry.
2. Robust 3D ray picking against object bounds/meshes rather than proximity-to-projection-point selection.
3. Axis-constrained gizmos for Move / Rotate / Scale, including visible handles and snap increments.
4. Multi-selection and group operations.
5. Transform undo transaction boundaries for continuous drag gestures; the current generic snapshot approach can create inefficient histories when many property edits occur.
6. Stable output-to-script linking by Luau/DataModel referent instead of display-name matching.

### Medium priority

7. Real material/shader system (normal/roughness/metallic/PBR where device capability allows).
8. Persistent recent-project database, thumbnails and crash recovery.
9. Virtualized Explorer for very large hierarchies.
10. Phone/tablet/orientation-specific layout variants.
11. Full asset library with thumbnails, import progress, cache eviction and offline management.
12. More complete UI/editor services: dialogs, keyboard behavior, accessibility, focus management and animation polish.

### Validation still required

- Build and install an Android APK from this exact tree in GitHub Actions or an Android SDK environment.
- Run physical-device UX checks on the target 4 GB ARM64 phone class.
- Measure startup time, FPS, memory, touch latency and large-project behavior.

## Completion rule

Do not label the whole application 100% complete until the remaining items above are implemented and re-audited.
