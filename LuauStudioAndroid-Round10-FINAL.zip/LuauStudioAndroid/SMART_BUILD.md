# Smart Build — Professional Offline Modeling Assistant

Smart Build is an offline construction layer inside Luau Studio Android. It is intentionally **not** a generic text-to-random-model generator.

## Design

A request is converted into a deterministic construction plan before anything is created. The plan contains:

- an organized `Model` root in Explorer;
- named Parts with deterministic positions, rotations and sizes;
- material/color assignment;
- parametric repetition where appropriate;
- mobile-safe part limits;
- a preview before creation;
- one grouped undo transaction for the complete build.

## Supported construction families

`casa`, `torre`, `escada`, `plataforma`, `ponte`, `galpão`, `sala`, `muro/cerca`, and `arco`.

The parser also recognizes size/material modifiers such as `pequena`, `tamanho 2`, `de madeira`, `de concreto`, `de metal`, `neon`, and numeric parameters such as `quantidade`/`andares`, `degraus`, `comprimento` and `partes` where applicable. It also accepts simple dimension pairs such as `20x12` and an explicit world anchor such as `em 5,2,-3`.

## Examples

```text
criar uma casa pequena de madeira com 2 janelas
criar uma torre de concreto quantidade 6
criar uma escada de metal degraus 20
criar uma plataforma neon partes 12
criar uma ponte de metal tamanho 2
criar um muro de tijolo comprimento 18
criar um arco de concreto tamanho 1.5
```

## Command Palette

The same editor exposes a searchable Command Palette. It provides direct access to Smart Build, creation tools, transform tools, selection, Explorer, Properties, Toolbox, Output, Performance, Save/Export and Play/Stop.

## Deliberate scope

This round does not claim arbitrary natural-language understanding or external AI inference. Requests outside the supported construction grammar are rejected with a useful prompt instead of producing an unrelated scene.

## Project Brain

Smart Build now includes a full-project planning layer called **Project Brain**. It handles high-level game intent before construction and produces a structured, engine-executable blueprint:

`USER → INTENT → PLAN → DEPENDENCIES → ENGINE EXECUTION → AUDIT`

The blueprint can describe the game's genre, core loop, systems, world structure, UI, scripts and mobile-safe object estimate. The current offline planner uses deterministic heuristics for several common game families and a generic fallback. It does not claim unrestricted natural-language understanding.

The engine is responsible for heavy construction. This keeps the AI/planner layer small while allowing future engine builders to add more object types, asset generation, world generators and runtime systems without changing the planning contract.

## Command Palette: Quick Actions + Recents

The Command Palette is a global mobile action search with:

- **Quick Actions** for common operations;
- **RECENTES** stored locally (maximum 8);
- full searchable action catalog;
- direct command parsing for simple coordinate/material/selection commands;
- Ctrl+K when a physical keyboard is attached.

Examples:

```text
Create Cylinder at 0, 5, 0
Select all Parts
Change Material to Metal
Duplicate Selection
Delete Selection
Open Explorer
```
