return {"result from dependency"}
